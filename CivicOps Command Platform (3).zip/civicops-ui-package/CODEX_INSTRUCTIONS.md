# CODEX INSTRUCTIONS — CivicOps UI integration (copy-paste, zero guessing)

> Goal: render the cinematic `/hackathon` page and the `/mobile-demo` page in the
> existing **ASP.NET Core MVC / Razor** CivicOps app, **without** touching the real app.
> Follow these steps literally. Do not improvise. Do not "improve" anything.

---

## STEP 0 — Copy files (exact paths, no renaming)

Copy the contents of this package into the repo root so the tree becomes:

```
<repo root>/
├─ Views/Home/Hackathon.cshtml
├─ Views/Home/MobileDemo.cshtml
└─ wwwroot/
   ├─ css/civicops-hackathon.css
   ├─ css/civicops-mobile-demo.css
   ├─ js/civicops-hackathon.js
   ├─ js/civicops-mobile-demo.js
   ├─ icons/civicops-192.png
   ├─ icons/civicops-512.png
   ├─ icons/civicops-maskable-512.png
   ├─ icons/apple-touch-icon-180.png
   ├─ icons/favicon-32.png
   ├─ icons/favicon-16.png
   ├─ manifest.webmanifest
   ├─ service-worker.js
   └─ offline.html
```

If a file already exists at these paths, **overwrite it**. Do not merge.

---

## STEP 1 — Add two controller actions

Open `Controllers/HomeController.cs`. Add these two methods **inside the existing
`HomeController` class** (do not create a new controller, do not delete existing actions):

```csharp
// --- CivicOps hackathon UI (standalone views, Layout = null) ---
public IActionResult Hackathon()  => View();
public IActionResult MobileDemo() => View();
```

That is all that goes in the controller. No attributes, no `[Route]`, no logic.

---

## STEP 2 — Add the two clean routes

Open `Program.cs`. Find the existing `app.MapControllerRoute(...)` for `"default"`.
Add these **two route registrations immediately BEFORE the default route** (order matters):

```csharp
app.MapControllerRoute(
    name: "hackathon",
    pattern: "hackathon",
    defaults: new { controller = "Home", action = "Hackathon" });

app.MapControllerRoute(
    name: "mobile-demo",
    pattern: "mobile-demo",
    defaults: new { controller = "Home", action = "MobileDemo" });

// >>> the existing default route stays AFTER these two, unchanged:
// app.MapControllerRoute(
//     name: "default",
//     pattern: "{controller=Home}/{action=Index}/{id?}");
```

---

## STEP 3 — Make "/" open the cinematic page

In `Controllers/HomeController.cs`, change the body of the existing `Index()` action to
redirect to the hackathon page. Keep the method signature; only change what it returns:

```csharp
public IActionResult Index() => RedirectToAction(nameof(Hackathon));
```

If `Index()` returned a model or did setup you still need elsewhere, keep that code in a
separate action and just make `Index()` return the redirect.

---

## STEP 4 — Serve the PWA manifest with the correct MIME type

In `Program.cs`, ensure static files are served (most templates already have
`app.UseStaticFiles();`). REPLACE that single call with the block below so
`.webmanifest` is served correctly (browsers ignore it otherwise):

```csharp
var civicopsTypes = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
civicopsTypes.Mappings[".webmanifest"] = "application/manifest+json";
app.UseStaticFiles(new Microsoft.AspNetCore.StaticFiles.StaticFileOptions
{
    ContentTypeProvider = civicopsTypes
});
```

If `app.UseStaticFiles();` was NOT present at all, add the block above in the same place
the default template puts it (after `app.UseRouting();` is fine; before `app.MapControllerRoute`).

The service worker (`/service-worker.js`) is served from `wwwroot` root by this same static-file
middleware — its scope is `/`. **Do NOT move `service-worker.js` into a subfolder.**

---

## STEP 5 — Build, run, verify

```bash
dotnet build
dotnet run
```

Open each URL and confirm:

- [ ] `/hackathon` → dark cinematic page. Hero has a glowing animated network.
      The "Five agents" section is a **carousel** (left/right arrows + dots + autoplay).
      NO Bootstrap navbar at the top.
- [ ] `/` → redirects to `/hackathon`.
- [ ] `/mobile-demo` → a phone shell; bottom tabs switch screens; the centre **+** button
      opens the report screen; "Submit to Band workflow" animates a 5-step handoff.
- [ ] `/Band`, `/app`, `/downloads` → still work exactly as before.
- [ ] Browser devtools → no 404s for `/css/...`, `/js/...`, `/icons/...`, `/manifest.webmanifest`.
- [ ] DevTools → Application → Manifest shows "CivicOps" with icons (installable PWA).

Then commit.

---

## ❌ DO NOT — the things that break it

1. **DO NOT wrap these views in `_Layout.cshtml`.**
   Both `Hackathon.cshtml` and `MobileDemo.cshtml` start with `@{ Layout = null; }` and
   render a FULL HTML document themselves. If you add a layout, force one, or remove the
   `Layout = null` line, the old Bootstrap nav/CSS bleeds in and the page looks broken.
   **This is the #1 cause of "incoherent UI / old layout mixing."**

2. **DO NOT add Bootstrap, jQuery, `site.css`, or `_ViewImports` styling to these pages.**
   They need ONLY their own two files (already linked inside each view). Adding the global
   theme causes the "front page looks like the old MVC site" problem.

3. **DO NOT rename the CSS scope classes** `.cv-hack` (hackathon) or `.cv-mob` (mobile).
   Every selector is namespaced under them. Renaming = total loss of styling.

4. **DO NOT edit, restyle, or "clean up"** `Views/Shared/*`, the existing `Index` view,
   `/Band`, `/app`, `/downloads`, or any other existing route/view. This package is ADDITIVE.

5. **DO NOT hardcode any API keys.** The page documents env vars
   (`BAND_API_KEY`, `AIML_API_KEY`, `FEATHERLESS_API_KEY`, `DEMO_MODE`, etc.) as text only.
   It makes NO network calls. Do not "wire them up" inside these views.

6. **DO NOT move `service-worker.js`** out of `wwwroot` root, and **do not move the icons**
   out of `wwwroot/icons/` — the manifest and registration use absolute paths
   (`/service-worker.js`, `/icons/...`).

7. **DO NOT convert these `.cshtml` files into partial views or components.** They are
   full standalone pages on purpose.

---

## If something is still wrong, report THIS

When asking for a fix, paste: (a) the exact URL, (b) the exact build/runtime error or the
console 404, and (c) whether you changed `Layout` or added any global CSS. 90% of failures
are violations of DO-NOT #1 or #2 above — check those first.

---

## Quick reference — routes this UI links to (must already exist in the app)

`/Band` · `/app` · `/downloads` · `/Home/DemoTour` · `/SUBMISSION.md`
These are existing app routes. This package does not create them; it only links to them.
If one doesn't exist yet, the link simply 404s until you add it — it does not break the page.
