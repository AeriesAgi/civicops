/* ============================================================
   CivicOps — Service Worker
   Makes the CivicOps mobile preview installable + offline-capable.
   Strategy:
     - Precache the app shell (mobile-demo CSS/JS, icons, offline page)
     - Navigations: network-first, fall back to cache, then /offline.html
     - Static assets (css/js/icons/fonts): stale-while-revalidate
   Bump CACHE_VERSION whenever you ship new shell assets.
   ============================================================ */
const CACHE_VERSION = "civicops-v1";
const PRECACHE = [
  "/mobile-demo",
  "/css/civicops-mobile-demo.css",
  "/js/civicops-mobile-demo.js",
  "/icons/civicops-192.png",
  "/icons/civicops-512.png",
  "/icons/civicops-maskable-512.png",
  "/icons/apple-touch-icon-180.png",
  "/manifest.webmanifest",
  "/offline.html"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) =>
      // addAll is atomic; use individual puts so one 404 can't break install
      Promise.allSettled(PRECACHE.map((url) => cache.add(url)))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  const sameOrigin = url.origin === self.location.origin;

  // HTML navigations: network-first, fall back to cache, then offline page
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (sameOrigin) {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() =>
          caches.match(req).then((cached) => cached || caches.match("/offline.html"))
        )
    );
    return;
  }

  // Same-origin static assets: stale-while-revalidate
  if (sameOrigin && /\.(?:css|js|png|svg|woff2?|webmanifest)$/.test(url.pathname)) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const network = fetch(req)
          .then((res) => {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
            return res;
          })
          .catch(() => cached);
        return cached || network;
      })
    );
    return;
  }

  // Cross-origin (e.g. Google Fonts): cache-first, network fallback
  event.respondWith(caches.match(req).then((cached) => cached || fetch(req)));
});
