/* ============================================================
   CivicOps — Native mobile / PWA preview logic
   - Bottom tab switching between 5 screens
   - Center action button -> jumps to Report intake
   - Report intake: live category/priority preview +
     simulated Band handoff result after submit
   - Persists the active tab to localStorage
   No external libraries. No network calls.
   ============================================================ */
(function () {
  "use strict";

  var root = document.querySelector(".cv-mob");
  if (!root) return;

  var reduceMotion = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var STORE_KEY = "civicops.mobiledemo.tab";

  var screens = root.querySelectorAll(".cv-mob-body");
  var tabs = root.querySelectorAll(".cv-tab[data-screen]");
  var header = {
    title: root.querySelector(".cv-mh-title"),
    sub: root.querySelector(".cv-mh-sub")
  };

  var HEADINGS = {
    command: { t: "Command", s: "Live operations" },
    timeline: { t: "Incident", s: "Timeline · CIV-4821" },
    report: { t: "New report", s: "Citizen intake" },
    updates: { t: "Public updates", s: "Citizen-facing" },
    audit: { t: "Audit trail", s: "Supervisor view" }
  };

  function showScreen(name) {
    screens.forEach(function (s) {
      s.classList.toggle("is-active", s.getAttribute("data-screen") === name);
    });
    tabs.forEach(function (tb) {
      tb.classList.toggle("is-active", tb.getAttribute("data-screen") === name);
    });
    if (HEADINGS[name]) {
      if (header.title) header.title.textContent = HEADINGS[name].t;
      if (header.sub) header.sub.textContent = HEADINGS[name].s;
    }
    try { localStorage.setItem(STORE_KEY, name); } catch (e) {}
    // reset scroll of the newly shown screen
    var active = root.querySelector('.cv-mob-body[data-screen="' + name + '"]');
    if (active) active.scrollTop = 0;
  }

  tabs.forEach(function (tb) {
    tb.addEventListener("click", function () {
      showScreen(tb.getAttribute("data-screen"));
    });
  });

  var fab = root.querySelector(".cv-fab");
  if (fab) {
    fab.addEventListener("click", function () { showScreen("report"); });
  }

  // restore last tab (default: command). URL ?screen= wins (PWA shortcuts).
  var initial = "command";
  try {
    var saved = localStorage.getItem(STORE_KEY);
    if (saved && HEADINGS[saved]) initial = saved;
  } catch (e) {}
  try {
    var qs = new URLSearchParams(window.location.search).get("screen");
    if (qs && HEADINGS[qs]) initial = qs;
  } catch (e) {}
  showScreen(initial);

  /* --------------------------------------------------------
     REPORT INTAKE — live preview + Band handoff simulation
  -------------------------------------------------------- */
  var textarea = root.querySelector(".cv-textarea");
  var previewRow = root.querySelector(".cv-preview-row");
  var opts = root.querySelectorAll(".cv-intake-opt");
  var submitBtn = root.querySelector(".cv-submit-btn");
  var resultBox = root.querySelector(".cv-handoff-result");
  var intakeForm = root.querySelector(".cv-intake-form");

  // toggle photo / voice-note options
  opts.forEach(function (o) {
    o.addEventListener("click", function () { o.classList.toggle("is-on"); });
  });

  // deterministic keyword -> category/priority classifier (local, no API)
  function classify(text) {
    var t = (text || "").toLowerCase();
    var rules = [
      { k: ["water", "pipe", "burst", "leak", "flood"], cat: "Water", pri: "High", icon: "💧" },
      { k: ["fire", "smoke", "burning"], cat: "Fire", pri: "Critical", icon: "🔥" },
      { k: ["power", "electric", "outage", "cable", "transformer"], cat: "Power", pri: "High", icon: "⚡" },
      { k: ["pothole", "road", "traffic", "sign", "street"], cat: "Roads", pri: "Medium", icon: "🛣️" },
      { k: ["crime", "theft", "break", "security", "assault"], cat: "Security", pri: "High", icon: "🛡️" },
      { k: ["waste", "refuse", "bin", "dump", "rubbish"], cat: "Waste", pri: "Low", icon: "🗑️" }
    ];
    for (var i = 0; i < rules.length; i++) {
      for (var j = 0; j < rules[i].k.length; j++) {
        if (t.indexOf(rules[i].k[j]) !== -1) return rules[i];
      }
    }
    return { cat: "General", pri: "Medium", icon: "📋" };
  }

  function renderPreview() {
    if (!previewRow) return;
    var c = classify(textarea ? textarea.value : "");
    var chips = [
      c.icon + " " + c.cat,
      "Priority: " + c.pri,
      "Ward 7 · Marigold Rd"
    ];
    opts.forEach(function (o) {
      if (o.classList.contains("is-on")) chips.push(o.getAttribute("data-tag"));
    });
    previewRow.innerHTML = "";
    chips.forEach(function (label) {
      var span = document.createElement("span");
      span.className = "cv-preview-chip";
      span.textContent = label;
      previewRow.appendChild(span);
    });
  }

  if (textarea) {
    textarea.addEventListener("input", renderPreview);
    opts.forEach(function (o) { o.addEventListener("click", renderPreview); });
    renderPreview();
  }

  function runHandoff() {
    if (!resultBox) return;
    var c = classify(textarea ? textarea.value : "");
    var steps = resultBox.querySelectorAll(".cv-handoff-step");

    // fill in category-aware text for the dispatch step
    var dispatchText = resultBox.querySelector("[data-fill='dispatch']");
    if (dispatchText) {
      var routeMap = {
        Water: "Municipal Water Response · P1",
        Fire: "Fire & Rescue · P0",
        Power: "Utilities · Electrical · P1",
        Roads: "Roads & Infrastructure · P2",
        Security: "Security Response · P1",
        Waste: "Waste Management · P3",
        General: "Municipal Operations · P2"
      };
      dispatchText.textContent = "Routed to " + (routeMap[c.cat] || routeMap.General) + ".";
    }
    var triageText = resultBox.querySelector("[data-fill='triage']");
    if (triageText) {
      triageText.textContent = "Classified as " + c.cat + " · severity " + c.pri + ".";
    }

    resultBox.classList.add("is-shown");
    if (reduceMotion) {
      steps.forEach(function (s) { s.classList.add("is-in"); });
      resultBox.scrollIntoView ? null : null; // avoid scrollIntoView per guidelines
      return;
    }
    steps.forEach(function (s, i) {
      setTimeout(function () { s.classList.add("is-in"); }, 220 + i * 360);
    });
  }

  if (submitBtn) {
    submitBtn.addEventListener("click", function (e) {
      e.preventDefault();
      if (submitBtn.disabled) return;
      var label = submitBtn.querySelector("span");
      submitBtn.disabled = true;
      if (label) label.textContent = "Submitting to Band…";
      setTimeout(function () {
        if (label) label.textContent = "Submitted · workflow running";
        runHandoff();
        // gently bring the result into view within the scroll body
        var body = root.querySelector('.cv-mob-body[data-screen="report"]');
        if (body && resultBox) {
          body.scrollTo({ top: body.scrollHeight, behavior: reduceMotion ? "auto" : "smooth" });
        }
      }, reduceMotion ? 0 : 700);
    });
  }

  /* --------------------------------------------------------
     Live clock in the status bar (operational feel)
  -------------------------------------------------------- */
  var clock = root.querySelector(".cv-sb-time");
  if (clock) {
    var tick = function () {
      var d = new Date();
      var h = d.getHours(), m = d.getMinutes();
      clock.textContent = (h < 10 ? "0" + h : h) + ":" + (m < 10 ? "0" + m : m);
    };
    tick();
    setInterval(tick, 15000);
  }
})();
