/* ============================================================
   CivicOps — Band of Agents Hackathon page logic
   - Animated command network (Canvas 2D, DPR-capped)
   - Incident pulses + travelling signal packets
   - Scroll reveal (IntersectionObserver)
   - Agent-workflow active-step cycling
   - Scrollytelling demo scenario (sticky scene)
   - Navbar scroll state
   All guarded behind prefers-reduced-motion.
   No external libraries. No network calls.
   ============================================================ */
(function () {
  "use strict";

  var root = document.querySelector(".cv-hack");
  if (!root) return;

  var reduceMotion = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* --------------------------------------------------------
     1) NAVBAR scroll state
  -------------------------------------------------------- */
  var nav = root.querySelector(".cv-nav");
  if (nav) {
    var onScrollNav = function () {
      if (window.scrollY > 24) nav.classList.add("is-scrolled");
      else nav.classList.remove("is-scrolled");
    };
    onScrollNav();
    window.addEventListener("scroll", onScrollNav, { passive: true });
  }

  /* --------------------------------------------------------
     2) SCROLL REVEAL
  -------------------------------------------------------- */
  var revealEls = root.querySelectorAll(".cv-reveal");
  if (reduceMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach(function (el) { el.classList.add("is-in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add("is-in");
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    revealEls.forEach(function (el) { io.observe(el); });

    // Fallback: reveal anything currently in the viewport on scroll/resize,
    // and a final safety net so content is never permanently hidden if the
    // observer never fires (some embedded/offscreen contexts).
    var revealInView = function () {
      var vh = window.innerHeight || document.documentElement.clientHeight;
      revealEls.forEach(function (el) {
        if (el.classList.contains("is-in")) return;
        var r = el.getBoundingClientRect();
        if (r.top < vh * 0.92 && r.bottom > 0) {
          el.classList.add("is-in");
          io.unobserve(el);
        }
      });
    };
    window.addEventListener("scroll", revealInView, { passive: true });
    window.addEventListener("resize", revealInView, { passive: true });
    revealInView();
    setTimeout(revealInView, 400);
    setTimeout(function () {
      revealEls.forEach(function (el) { el.classList.add("is-in"); });
    }, 4000);
  }

  /* --------------------------------------------------------
     3) COMMAND NETWORK CANVAS
     Five agent nodes orbit a central Band core.
     Signal packets travel along the rails; incident
     pulses ripple out from the edge into intake.
  -------------------------------------------------------- */
  var canvas = root.querySelector(".cv-net-canvas");
  if (canvas && canvas.getContext) {
    var ctx = canvas.getContext("2d");
    var DPR = Math.min(window.devicePixelRatio || 1, 2);
    var W = 0, H = 0, cx = 0, cy = 0, R = 0;
    var raf = null, t0 = performance.now();

    var AGENTS = [
      { label: "Intake", color: "#00d4ff" },
      { label: "Triage", color: "#4da3ff" },
      { label: "Dispatch", color: "#ffc24d" },
      { label: "Comms", color: "#41e08d" },
      { label: "Audit", color: "#b86bff" }
    ];

    var packets = [];   // travelling signal packets {from,to,p,speed,color}
    var pulses = [];    // incident pulses {x,y,r,max,a}

    function resize() {
      var rect = canvas.getBoundingClientRect();
      W = Math.max(280, rect.width);
      H = Math.max(280, rect.height);
      canvas.width = Math.round(W * DPR);
      canvas.height = Math.round(H * DPR);
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      cx = W / 2;
      cy = H / 2;
      R = Math.min(W, H) * 0.36;
    }

    function nodePos(i, time) {
      var a = (i / AGENTS.length) * Math.PI * 2 - Math.PI / 2 + time * 0.00006;
      return { x: cx + Math.cos(a) * R, y: cy + Math.sin(a) * R };
    }

    function spawnPacket() {
      // packet hops from the core to an agent, or agent->next agent
      var roll = Math.random();
      if (roll < 0.5) {
        var to = Math.floor(Math.random() * AGENTS.length);
        packets.push({ kind: "core", to: to, p: 0, speed: 0.012 + Math.random() * 0.01, color: AGENTS[to].color });
      } else {
        var from = Math.floor(Math.random() * AGENTS.length);
        var nxt = (from + 1) % AGENTS.length;
        packets.push({ kind: "chain", from: from, to: nxt, p: 0, speed: 0.01 + Math.random() * 0.008, color: AGENTS[nxt].color });
      }
    }

    function spawnPulse() {
      var i = 0; // pulses arrive at the Intake node
      var pos = nodePos(i, performance.now() - t0);
      pulses.push({ x: pos.x, y: pos.y, r: 4, max: R * 0.7, a: 0.5 });
    }

    function draw(now) {
      var time = now - t0;
      ctx.clearRect(0, 0, W, H);

      // --- connecting rails: core -> each node + ring chain ---
      ctx.lineWidth = 1;
      for (var i = 0; i < AGENTS.length; i++) {
        var p = nodePos(i, time);
        // spoke
        var g = ctx.createLinearGradient(cx, cy, p.x, p.y);
        g.addColorStop(0, "rgba(0,212,255,0.30)");
        g.addColorStop(1, "rgba(0,212,255,0.05)");
        ctx.strokeStyle = g;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        // ring chain to next
        var pn = nodePos((i + 1) % AGENTS.length, time);
        ctx.strokeStyle = "rgba(0,212,255,0.10)";
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(pn.x, pn.y);
        ctx.stroke();
      }

      // --- incident pulses ---
      for (var u = pulses.length - 1; u >= 0; u--) {
        var pu = pulses[u];
        pu.r += 1.4;
        pu.a -= 0.006;
        if (pu.a <= 0 || pu.r > pu.max) { pulses.splice(u, 1); continue; }
        ctx.strokeStyle = "rgba(255,90,90," + pu.a.toFixed(3) + ")";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(pu.x, pu.y, pu.r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // --- travelling packets ---
      for (var k = packets.length - 1; k >= 0; k--) {
        var pk = packets[k];
        pk.p += pk.speed;
        if (pk.p >= 1) { packets.splice(k, 1); continue; }
        var sx, sy, ex, ey;
        if (pk.kind === "core") {
          sx = cx; sy = cy;
          var tp = nodePos(pk.to, time); ex = tp.x; ey = tp.y;
        } else {
          var fp = nodePos(pk.from, time); sx = fp.x; sy = fp.y;
          var tp2 = nodePos(pk.to, time); ex = tp2.x; ey = tp2.y;
        }
        var x = sx + (ex - sx) * pk.p;
        var y = sy + (ey - sy) * pk.p;
        ctx.fillStyle = pk.color;
        ctx.shadowColor = pk.color;
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // --- agent nodes ---
      for (var n = 0; n < AGENTS.length; n++) {
        var np = nodePos(n, time);
        var pulse = 1 + Math.sin(time * 0.003 + n) * 0.12;
        // halo
        ctx.fillStyle = "rgba(0,212,255,0.05)";
        ctx.beginPath();
        ctx.arc(np.x, np.y, 26 * pulse, 0, Math.PI * 2);
        ctx.fill();
        // disc
        ctx.fillStyle = "#070b14";
        ctx.beginPath();
        ctx.arc(np.x, np.y, 17, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = AGENTS[n].color;
        ctx.lineWidth = 1.6;
        ctx.shadowColor = AGENTS[n].color;
        ctx.shadowBlur = 14;
        ctx.beginPath();
        ctx.arc(np.x, np.y, 17, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
        // label
        ctx.fillStyle = "rgba(232,244,255,0.85)";
        ctx.font = "600 11px 'JetBrains Mono', monospace";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        var lx = np.x + (np.x - cx) * 0.34;
        var ly = np.y + (np.y - cy) * 0.34;
        ctx.fillText(AGENTS[n].label.toUpperCase(), lx, ly);
      }

      // --- central Band core ---
      var corePulse = 1 + Math.sin(time * 0.0025) * 0.16;
      var cg = ctx.createRadialGradient(cx, cy, 2, cx, cy, 46 * corePulse);
      cg.addColorStop(0, "rgba(0,212,255,0.55)");
      cg.addColorStop(0.5, "rgba(0,212,255,0.16)");
      cg.addColorStop(1, "rgba(0,212,255,0)");
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(cx, cy, 46 * corePulse, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#04060c";
      ctx.beginPath();
      ctx.arc(cx, cy, 30, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(0,212,255,0.9)";
      ctx.lineWidth = 2;
      ctx.shadowColor = "#00d4ff";
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(cx, cy, 30, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#6be4ff";
      ctx.font = "700 12px 'JetBrains Mono', monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("BAND", cx, cy);

      raf = requestAnimationFrame(draw);
    }

    function drawStatic() {
      // single frame end-state for reduced motion / no rAF
      draw(t0);
    }

    resize();
    window.addEventListener("resize", function () {
      resize();
      if (reduceMotion) drawStatic();
    }, { passive: true });

    if (reduceMotion) {
      drawStatic();
    } else {
      // seed some activity, then run
      for (var s = 0; s < 3; s++) spawnPacket();
      setInterval(function () { if (packets.length < 14) spawnPacket(); }, 520);
      setInterval(spawnPulse, 2600);
      raf = requestAnimationFrame(draw);

      // pause when offscreen to save battery
      if ("IntersectionObserver" in window) {
        var visObs = new IntersectionObserver(function (ents) {
          ents.forEach(function (e) {
            if (e.isIntersecting && !raf) { raf = requestAnimationFrame(draw); }
            else if (!e.isIntersecting && raf) { cancelAnimationFrame(raf); raf = null; }
          });
        }, { threshold: 0 });
        visObs.observe(canvas);
      }
    }
  }

  /* --------------------------------------------------------
     4) AGENT WORKFLOW — cycle the active node
  -------------------------------------------------------- */
  var agViewport = root.querySelector(".cv-ag-viewport");
  var agTrack = root.querySelector(".cv-ag-track");
  var agCards = root.querySelectorAll(".cv-agent");
  var agDots = root.querySelectorAll(".cv-ag-dot");
  if (agViewport && agTrack && agCards.length) {
    var agIdx = 0;
    var agHover = false;

    var layoutAg = function () {
      var gap = 22;
      var cw = agCards[0].getBoundingClientRect().width + gap;
      var max = Math.max(0, agTrack.scrollWidth - agViewport.clientWidth);
      var x = Math.min(agIdx * cw, max);
      agTrack.style.transform = "translate3d(" + (-x) + "px,0,0)";
      agCards.forEach(function (el, i) { el.classList.toggle("is-active", i === agIdx); });
      agDots.forEach(function (d, i) { d.classList.toggle("is-active", i === agIdx); });
    };
    var goAg = function (i) {
      agIdx = (i + agCards.length) % agCards.length;
      layoutAg();
    };

    agDots.forEach(function (d, i) { d.addEventListener("click", function () { goAg(i); }); });
    var prevBtn = root.querySelector("[data-ag-prev]");
    var nextBtn = root.querySelector("[data-ag-next]");
    if (prevBtn) prevBtn.addEventListener("click", function () { goAg(agIdx - 1); });
    if (nextBtn) nextBtn.addEventListener("click", function () { goAg(agIdx + 1); });
    agViewport.addEventListener("mouseenter", function () { agHover = true; });
    agViewport.addEventListener("mouseleave", function () { agHover = false; });
    window.addEventListener("resize", layoutAg, { passive: true });

    layoutAg();
    if (!reduceMotion) {
      setInterval(function () { if (!agHover) goAg(agIdx + 1); }, 3600);
    }
  }

  /* --------------------------------------------------------
     5) SCROLLYTELLING DEMO SCENARIO
     As each step scrolls into the centre band, activate it
     and reveal the matching messages in the sticky window.
  -------------------------------------------------------- */
  var steps = root.querySelectorAll(".cv-scrolly-step");
  var msgs = root.querySelectorAll(".cv-demo-msg");
  if (steps.length) {
    var activateStep = function (idx) {
      steps.forEach(function (s, i) { s.classList.toggle("is-active", i === idx); });
      // reveal messages up to and including this step
      msgs.forEach(function (m) {
        var mi = parseInt(m.getAttribute("data-step"), 10);
        m.classList.toggle("is-shown", mi <= idx);
      });
    };
    activateStep(0);

    if (!reduceMotion && "IntersectionObserver" in window) {
      var stepObs = new IntersectionObserver(function (ents) {
        ents.forEach(function (e) {
          if (e.isIntersecting) {
            var idx = parseInt(e.target.getAttribute("data-step"), 10);
            activateStep(idx);
          }
        });
      }, { threshold: 0.6, rootMargin: "-30% 0px -30% 0px" });
      steps.forEach(function (s) { stepObs.observe(s); });
    } else {
      // reduced motion: show everything
      steps.forEach(function (s) { s.classList.add("is-active"); });
      msgs.forEach(function (m) { m.classList.add("is-shown"); });
    }
  }

  /* --------------------------------------------------------
     6) Smooth anchor scrolling for in-page CTAs
  -------------------------------------------------------- */
  root.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener("click", function (ev) {
      var id = a.getAttribute("href");
      if (id.length < 2) return;
      var target = root.querySelector(id);
      if (!target) return;
      ev.preventDefault();
      var top = target.getBoundingClientRect().top + window.scrollY - 90;
      window.scrollTo({ top: top, behavior: reduceMotion ? "auto" : "smooth" });
    });
  });
})();
