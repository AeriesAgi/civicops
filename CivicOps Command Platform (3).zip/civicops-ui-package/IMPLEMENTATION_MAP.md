# CivicOps — Band of Agents · UI/UX Implementation Map

This package is the **cinematic command-platform UI layer** for the existing CivicOps
ASP.NET Core MVC / Razor app. It is implementation-ready: drop the files in, wire two
routes, reference nothing else. Every file is isolated from the old global/Bootstrap
theme so it cannot drift into the existing app.

---

## 1 · File tree

```
CivicOps/                                  (repo root)
├─ Views/
│  └─ Home/
│     ├─ Hackathon.cshtml          ← NEW · cinematic landing/demo page  (route: /hackathon)
│     └─ MobileDemo.cshtml         ← NEW · native mobile/PWA preview     (route: /mobile-demo)
├─ wwwroot/
│  ├─ css/
│  │  ├─ civicops-hackathon.css    ← NEW · all hackathon-page styling (scoped .cv-hack)
│  │  └─ civicops-mobile-demo.css  ← NEW · all mobile-preview styling (scoped .cv-mob)
│  ├─ js/
│  │  ├─ civicops-hackathon.js     ← NEW · canvas network, scroll choreography, reveals
│  │  └─ civicops-mobile-demo.js   ← NEW · tab switching, intake preview, Band handoff sim
│  ├─ icons/
│  │  ├─ civicops-192.png          ← NEW · PWA icon (any)
│  │  ├─ civicops-512.png          ← NEW · PWA icon (any)
│  │  ├─ civicops-maskable-512.png ← NEW · PWA icon (maskable / Android adaptive)
│  │  ├─ apple-touch-icon-180.png  ← NEW · iOS home-screen icon
│  │  ├─ favicon-32.png            ← NEW · favicon
│  │  └─ favicon-16.png            ← NEW · favicon
│  ├─ manifest.webmanifest         ← NEW · PWA manifest (installable)
│  ├─ service-worker.js            ← NEW · offline cache + install
│  └─ offline.html                 ← NEW · offline fallback page
└─ IMPLEMENTATION_MAP.md           ← NEW · this file
```

Both views use `Layout = null` — they render a **complete HTML document** and pull in
ONLY their own scoped CSS/JS. No `_Layout.cshtml`, no `_ViewStart`, no Bootstrap, no
old nav. Nothing in `Views/Shared` is touched.

---

## 2 · Routes & controller wiring

Add two actions to the existing `HomeController` (or wherever `Views/Home` is served):

```csharp
// HomeController.cs
public IActionResult Hackathon()  => View();   // GET /Home/Hackathon  -> Views/Home/Hackathon.cshtml
public IActionResult MobileDemo() => View();   // GET /Home/MobileDemo -> Views/Home/MobileDemo.cshtml
```

### Friendly routes (required by the brief)

Map the clean URLs in `Program.cs` **before** the default route:

```csharp
app.MapControllerRoute(
    name: "hackathon",
    pattern: "hackathon",
    defaults: new { controller = "Home", action = "Hackathon" });

app.MapControllerRoute(
    name: "mobile-demo",
    pattern: "mobile-demo",
    defaults: new { controller = "Home", action = "MobileDemo" });

// existing default route stays last
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
```

### Make `/` open the cinematic page

Pick **one** (redirect is the lowest-risk option):

```csharp
// Option A — redirect root to /hackathon (recommended; preserves Index for internal use)
public IActionResult Index() => RedirectToAction(nameof(Hackathon));

// Option B — change the default route's action to Hackathon
//   pattern: "{controller=Home}/{action=Hackathon}/{id?}"
```

---

## 3 · What each file expects

| File | Route it serves | Layout | References | Scope |
|---|---|---|---|---|
| `Views/Home/Hackathon.cshtml` | `/hackathon`, `/` | `Layout = null` | `~/css/civicops-hackathon.css`, `~/js/civicops-hackathon.js` | `.cv-hack` |
| `Views/Home/MobileDemo.cshtml` | `/mobile-demo` | `Layout = null` | `~/css/civicops-mobile-demo.css`, `~/js/civicops-mobile-demo.js` | `.cv-mob` |

- Asset links use `~/...` + `asp-append-version="true"` (cache-busting). They resolve via
  `UseStaticFiles()` — already enabled in any standard MVC app. No bundler required.
- `@DateTime.UtcNow.Year` is the only server-side expression (footer copyright). Safe.
- Fonts (Space Grotesk / Inter / JetBrains Mono) load from Google Fonts inside each CSS
  file via `@import`. To go fully offline, self-host them in `wwwroot/fonts` and replace
  the `@import` line — see §7.

---

## 4 · Outbound links (existing routes this UI points at)

These are referenced from the hackathon page and mobile preview. Keep them working;
none are created by this package:

| Link | Used on | Purpose |
|---|---|---|
| `/Band` | hero, entry grid, footer | Band multi-agent demo |
| `/app` | nav, entry grid, footer, mobile | Real CivicOps app / PWA surface |
| `/downloads` | entry grid, footer, mobile | APK / PWA download hub |
| `/mobile-demo` | entry grid | This package's mobile preview |
| `/Home/DemoTour` | hero ("Watch demo"), entry grid, footer | Judge tour (if present) |
| `/SUBMISSION.md` | footer | Submission notes (serve as static file or route; see note) |
| `https://github.com/AeriesAgi/civicops` | footer | Source repo |

**If a target route does not exist yet:** the link is still safe (renders a normal 404
until you add it). `/SUBMISSION.md` — either serve the markdown as a static file
(`app.UseStaticFiles()` will serve `wwwroot/SUBMISSION.md`) or point the footer link at
your docs route. Update the `href` in `Hackathon.cshtml` footer if your path differs.

---

## 5 · What Codex MUST do / MUST NOT do

**DO**
- Copy the 7 files to the exact paths in §1.
- Add the two controller actions and the two friendly routes (§2).
- Redirect `/` → `/hackathon` (§2, Option A).
- Build + run + smoke-test the three URLs, then commit.

**DO NOT**
- Do **not** wrap these views in `_Layout.cshtml`. They are standalone (`Layout = null`).
  Wrapping them re-introduces the old Bootstrap nav and breaks the cinematic look.
- Do **not** add Bootstrap, jQuery, or the old site CSS to these pages. They need nothing
  but their own two files.
- Do **not** rename the root CSS scope classes (`.cv-hack`, `.cv-mob`) — every selector
  is namespaced under them; renaming breaks all styling.
- Do **not** edit `Views/Shared/*`, the existing `Index`, `/Band`, `/app`, or `/downloads`
  views. This package is additive.
- Do **not** hardcode any API keys. Provider config is env-var only (§6).
- Do **not** claim live partner calls work. The partner section is written as
  "optional adapters / integration-ready" on purpose (§8).

---

## 6 · Environment variables (documented on the page, never committed)

The hackathon page renders these as **documentation only** — it reads no secrets and
makes no network calls. Wire them server-side in your agent/provider layer:

```
BAND_API_KEY          # Band coordination access
BAND_API_BASE_URL     # Band endpoint
AIML_API_KEY          # optional — AI/ML API
AIML_API_BASE_URL     # optional provider URL
AIML_MODEL            # optional model id
FEATHERLESS_API_KEY   # optional — Featherless AI
FEATHERLESS_MODEL     # optional model id
DEMO_MODE             # "true" = deterministic local fallback (no external calls)
```

When keys are absent (or `DEMO_MODE=true`), the product runs the deterministic local
fallback. The mobile preview's intake classifier is a **client-side keyword matcher** —
it demonstrates the flow with zero network dependency and is safe to ship as-is.

---

## 7 · Assets required

**All included — nothing missing, nothing paid, no large video files.**

- UI icons: inline SVG (Lucide-weight, 1.6px stroke) — embedded in the markup.
- Brand mark: inline hexagon SVG in the nav/footer.
- Hero visual: drawn at runtime on `<canvas>` (no image file).
- **App/launcher icons: real PNGs shipped in `wwwroot/icons/`** (192, 512, maskable-512,
  apple-touch-180, favicon 16/32) — generated from the CivicOps hexagon mark.
- Fonts: Google Fonts `@import` (swap to self-hosted for offline — replace the first
  `@import` line in each CSS with local `@font-face` rules pointing at `wwwroot/fonts`).

Optional polish (not required to ship): drop a real OG/share image at
`wwwroot/img/civicops-og.png` and add `<meta property="og:image">` to `Hackathon.cshtml`.

---

## 7b · PWA / APK (installable build)

The mobile preview is a full **installable PWA**. Files involved:
`wwwroot/manifest.webmanifest`, `wwwroot/service-worker.js`, `wwwroot/offline.html`,
`wwwroot/icons/*`. Both views link the manifest + icons; `MobileDemo.cshtml` registers
the service worker on load.

**Serve correctly (ASP.NET Core):**
```csharp
app.UseStaticFiles();   // already present — serves /manifest.webmanifest, /service-worker.js, /icons/*
```
If `.webmanifest` returns 404 or the wrong type, register the MIME type:
```csharp
var provider = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider();
provider.Mappings[".webmanifest"] = "application/manifest+json";
app.UseStaticFiles(new StaticFileOptions { ContentTypeProvider = provider });
```
The service worker is served from the site root (`/service-worker.js`) so its scope is `/`
— do not move it into a subfolder or it can't control navigations.

**PWA install:** open `/mobile-demo` over **HTTPS** (or `localhost`) → browser shows
"Install app". `start_url` is `/mobile-demo`; manifest shortcuts deep-link to
`/mobile-demo?screen=report` and `?screen=command` (the JS honours `?screen=`).

**APK:** wrap the PWA — no extra design work:
- **Bubblewrap / TWA** (recommended): `npx @bubblewrap/cli init --manifest https://YOUR_HOST/manifest.webmanifest`, then `bubblewrap build` → signed `.apk`/`.aab`.
- or **PWABuilder.com** → paste the deployed URL → download the Android package.
- or **Capacitor** if you want a native shell around the same web assets.
All three consume the manifest + icons already in this package.

---

## 8 · Fallback behaviour (built in)

| Concern | Behaviour |
|---|---|
| **WebGL risk** | The command network is **Canvas 2D**, not WebGL — broadly stable. Caps `devicePixelRatio` at 2. |
| **Canvas unsupported** | If `getContext('2d')` is unavailable, the hero simply shows the static background grid/glow; the rest of the page is unaffected. |
| **Offscreen / battery** | The canvas animation pauses via `IntersectionObserver` when scrolled out of view. |
| **`prefers-reduced-motion`** | All transitions/animations collapse to end-states; the canvas renders a single static frame; scroll reveals show immediately; the Band handoff appears instantly. |
| **No `IntersectionObserver`** | Scroll reveals fall back to a scroll/timeout reveal (content is never permanently hidden). |
| **JS disabled** | The page is fully readable — all content is real HTML; only the live animations are absent. |
| **Provider keys absent** | Deterministic local demo (intake classifier is client-side keyword matching). |
| **Offline (installed PWA)** | Service worker serves the cached shell; unknown navigations fall back to `/offline.html`. |
| **Service worker unsupported** | Registration is wrapped in a feature check + `.catch()` — the page works normally, just not offline-installable. |

---

## 9 · Partner section copy (as shipped — keep honest)

- **Band — Core · required.** Multi-agent collaboration and coordination layer.
  Orchestrates handoffs between the CivicOps agents; enforces the intake → triage →
  dispatch → comms → audit order; makes agent collaboration visible in the demo.
- **AI/ML API — Optional adapter.** Unified access to many models through one interface
  for reasoning, extraction, summarisation, multimodal and automation-heavy workflows.
  Used as an optional model provider — not required for the fallback demo.
- **Featherless AI — Optional adapter.** Serverless open-source inference,
  OpenAI-compatible style, for specialised agent reasoning/generation. Base URL
  `https://api.featherless.ai/v1`, chat endpoint `/v1/chat/completions`. Optional only.

> Wording is deliberately "optional / integration-ready". Do not upgrade it to "live"
> unless those calls have actually been tested end-to-end.

---

## 10 · Mobile / PWA copy & screens

Five screens, switched by the bottom tab bar + centre action button (FAB → New report):

1. **Command** — active incident with stage progress, live command feed, agent-status grid (Band).
2. **Timeline** — reported → classified → dispatched → public update → audit logged.
3. **Report intake** — text report, photo + voice-note options, live category/priority
   preview, "Submit to Band workflow". After submit, the **Band handoff result** animates
   in (Intake → Triage → Dispatch → Comms → Audit), with category-aware routing text.
4. **Public updates** — citizen-friendly message, reference number, status step timeline.
5. **Audit trail** — timestamped decisions, agent handoffs, supervisor summary.

Behaviour: dark status bar, premium header that retitles per screen, glass cards, large
touch targets (≥44px), active tab persisted to `localStorage`, full-bleed on real phones
(`max-width: 460px`). Links back to `/app` and `/downloads` in the intro header.

---

## 11 · Screenshot / video recording notes (for the submission)

- **Hero (first 5s):** load `/hackathon`, let the command network settle (~2s). The
  central **BAND** core pulses; cyan signal packets travel the spokes; red incident pulses
  ripple from the Intake node.
- **Agent workflow:** scroll to `#workflow` — the active agent card cycles every ~1.8s
  along the Band rail. Pause on each for stills.
- **Scrollytelling:** scroll slowly through `#scenario`; the sticky incident window reveals
  one agent message per step (burst-water-pipe scenario) — great for a screen recording.
- **Architecture:** `#architecture` is one clean horizontal diagram, ideal for a single
  high-res still.
- **Mobile:** open `/mobile-demo`. Record: Command → tap FAB → type/keep the report →
  "Submit to Band workflow" → the 5-step Band handoff animates in → switch to Updates →
  Audit. Use a 390×844 device frame or shoot on a real phone (it goes full-bleed).
- **Reduced motion:** to capture clean stills, set OS "reduce motion" — animations resolve
  to end-states instantly.

---

### Quick verify checklist
- [ ] `/hackathon` renders the dark cinematic page (no Bootstrap nav).
- [ ] `/` redirects to `/hackathon`.
- [ ] `/mobile-demo` renders the phone shell; tabs + FAB + submit handoff work.
- [ ] `/Band`, `/app`, `/downloads` still resolve.
- [ ] No console errors; build + tests pass.
