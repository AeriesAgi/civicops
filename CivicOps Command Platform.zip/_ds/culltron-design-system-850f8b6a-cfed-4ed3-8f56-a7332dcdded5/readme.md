# Culltron Design System

**Software. Intelligence. Infrastructure. Built for the next economy.**

A premium, launch-ready design system and full marketing-website concept for **Culltron** — a South African technology company building AI-powered software, desktop apps, municipal systems, automation tools, developer tools and client-facing business solutions.

This system is engineered so a developer can convert it directly into the live Culltron website, and so a design agent can generate on-brand interfaces, decks and assets at any time.

---

## 1 · Company & product context

Culltron operates as **one technology brand spanning a full ecosystem** — not a single app and not an agency. The internal design language is codenamed **Gridlight**: a dark "void" canvas, cyan energy-line accents, and holographic panels. This design system aligns 1:1 with the live Gridlight tokens and extends them for premium marketing.

**Product ecosystem (from the real source repos):**

| Layer | Products |
|---|---|
| **Desktop · Max suite** | Office Max, PDF Max, Studio Max, Video Max, Data Max, Diagram Max, Mail Max, Forge Max |
| **Intelligence** | **Aria** (user-controlled AI workspace), **Sentinel** (runtime security) |
| **Operational platforms** | **AfriGrid Nexus** (municipal resilience), **CivicOps** (citizen service & ops intake), **Smart Port Flow** (port & logistics intelligence) |
| **Developer / automation** | Forge / API suite, App Hub, DevBox, Asset Store |

**Positioning:** intelligent software systems for businesses, municipalities, funders, creators, developers and operations teams. Offline-first, model-transparent, security-conscious, commercially serious.

### Sources used (the reader can explore these further)
- **GitHub — main brand:** https://github.com/AeriesAgi/Culltron
- **GitHub — platform / branding source of truth:** https://github.com/AeriesAgi/Affiliate  → `shared/ui/culltron.css` (the Gridlight design system), `shared/registry/apps.json` (the product registry + per-app accents), `branding/icons/**` (the real hexagonal app glyphs, imported into `assets/icons/`)
- **GitHub — operational platforms:** https://github.com/AeriesAgi/civicops (real `civicops-theme.css`), https://github.com/AeriesAgi/culltron-smart-port-flow, https://github.com/AeriesAgi/AgriGrid
- **Uploaded brand assets:** the Culltron cyan-hexagon wordmark + favicon (`uploads/`), composited into `assets/`.

> Access note: these are private AeriesAgi repos. Nothing is assumed to be reachable by the reader — values were lifted into this system so it stands alone.

---

## 2 · Visual identity (overview)

Culltron looks like **operational intelligence from the future, engineered in Africa**: Tron-grade cyan on near-black, technical display type, live grid/scanline motion, holographic product glyphs. Premium and investor-ready — never crypto, childish or templated.

The full **VISUAL FOUNDATIONS**, **CONTENT FUNDAMENTALS** and **ICONOGRAPHY** sections are below.

---

## 3 · CONTENT FUNDAMENTALS — how Culltron writes

**Voice:** confident, precise, commercially serious. We sound like a company that already ships.

- **Person:** "Culltron builds…" (third person for the brand) and direct **"you"** for the reader ("Tell us what you run"). Never "I".
- **Casing:** Sentence case for almost everything — headlines, buttons, nav. Product names keep their proper case (Office Max, AfriGrid Nexus, Aria). **UPPERCASE** is reserved for mono eyebrows/labels with wide tracking ("WHAT CULLTRON BUILDS").
- **Tone words we use:** launch-ready, intelligent systems, operational software, AI-powered workflows, digital infrastructure, automation, product ecosystem, offline-first, model-transparent, built for businesses, municipalities and modern teams.
- **Words we never use:** MVP, idea stage, "revolutionary", "disrupt", "to the moon", emoji-as-tone, exclamation-driven hype. No fake urgency.
- **Headlines:** short, declarative, often two lines with the second line in the cyan gradient. e.g. *"Intelligent software systems / for the next economy."*
- **Subheads:** one sentence, concrete, name the audiences. ~20–34 words.
- **Body:** plain, specific, benefit-first. Short sentences. No filler stats — every number must mean something.
- **CTAs:** verb-led and calm — *Explore Culltron*, *Request a Demo*, *Talk on WhatsApp*, *Download for desktop*. Three-tier pattern: primary (cyan) / secondary (outline) / WhatsApp (green).
- **Eyebrows:** 1–3 words, mono, uppercase ("Product ecosystem", "Operations intelligence").

**Mini examples**
- Hero: *"Build smarter. Operate faster. Launch with Culltron."*
- Proof: *"Funder-ready foundations, commercial from day one."*
- Mission: *"We build the intelligent software layer for the next economy — engineered in South Africa, designed to operate anywhere."*

---

## 4 · VISUAL FOUNDATIONS — the Culltron look

**Color & vibe.** Cool, high-contrast, electric. The canvas is the **void** (`#04060c`) graduating through graphite/navy panels (`#0b1220 → #121c33`). The single hero accent is **Culltron cyan `#00d4ff`** (with `#6be4ff` highlight). A controlled secondary palette carries product identity: data blue `#4da3ff`, design violet `#b86bff`, gold `#ffc24d`, ember `#ff7a45`, ok-green `#41e08d`. Status: green/amber/red. Imagery vibe = cool, dark, neon-on-black; glyphs glow rather than cast realistic shadows.

**Typography.** Display = **Space Grotesk** (technical, wide, slightly futuristic) at 700, tight tracking (-0.04em) — used for all headlines, with an optional white→cyan gradient clip. Body/UI = **Inter** (the in-product stack). Data/eyebrows/labels = **JetBrains Mono**, uppercase, wide tracking (0.16–0.18em). *Substitution flag: the shipping apps use Inter only; Space Grotesk + JetBrains Mono are an intentional premium elevation for marketing — see Caveats.*

**Spacing & layout.** 8px base grid. Generous section rhythm (`--section-y` clamps 4→9rem). Containers 1240/1440px with fluid gutters. Strong hierarchy, lots of negative space; content sits on `z-index:1` above a fixed background grid.

**Backgrounds.** The signature is a **perspective grid floor + faint global grid** in low-opacity cyan, masked so it fades out. Radial cyan/violet glows bloom from the top and corners. The hero adds an animated Tron grid (canvas), drifting light particles, a rotating conic "scan" sweep, and a holographic product constellation (real app glyphs orbiting the Culltron core). Never use noise/grain; never warm gradients.

**Motion.** Purposeful, smooth, never bouncy-cute. Easing `cubic-bezier(.22,1,.36,1)` for entrances; durations 0.15/0.28/0.5s. Patterns: fade-and-rise on scroll (`Reveal`), count-up metrics, masked headline reveals, SVG line-draw on charts, marquee, slow orbital spins, a soft core pulse. **Everything degrades gracefully under `prefers-reduced-motion`** (end-states shown, loops disabled).

**Hover / press.** Buttons lift 1px + brighten ~6% on hover; cards lift 4px and brighten their border to `--line-strong`. Links go white. Press = settle back to translateY(0). Focus = cyan ring (`--glow-focus`).

**Borders, radii, shadows.** Borders are **cyan energy hairlines** (`rgba(0,212,255,.16)`), strengthening to `.38` when active/hover. Radii: inputs/chips 12px, panels 20px, cards 28px, big surfaces 36px, pills 999px. Elevation pairs a deep black shadow with a faint cyan glow (`--shadow-card`); the pure **`--glow`** is used on accent elements. Glass/blur (`backdrop-filter`) is reserved for sticky chrome (navbar) only — used sparingly, never everywhere.

**Cards.** Gradient graphite fill (`--grad-card`), 1px cyan hairline, 28px radius, soft shadow + glow; optional hover lift. This single recipe (the `Card` primitive) underpins product, service, case-study, pricing and post cards.

---

## 5 · ICONOGRAPHY

- **Brand / product glyphs:** Culltron's real icon language is a **hexagonal outline mark** rendered in each product's accent color, on a dark tile. All product glyphs are imported into `assets/icons/` (`app-office-max.png`, `app-aria.png`, `app-pdf-max.png`, …, plus `culltron-mark-256/512.png`). **Always use these PNGs** for product references — in product cards, the hero constellation, footers and detail pages. Don't redraw them.
- **UI line icons:** thin, rounded **1.6px-stroke outline icons** (Lucide-weight). These are drawn inline as small SVG `<path>` sets inside the kits (feature tiles, service cards, contact channels). If you need a broader set, link **Lucide** from CDN at the same 1.6 stroke — it matches. *(No icon font ships in the source; this is the documented substitute.)*
- **Status dots:** small glowing circles in semantic colors.
- **Emoji:** **not used** as brand tone. (The only emoji-like marks are functional check/arrow glyphs `✓ → ▸ +`.)
- **Logo lockup:** hexagon mark + "Cull**tron**" wordmark, the "tron" in cyan with a text-glow. See `guidelines/brand-logo.card.html`.

---

## 6 · Index — what's in this system

**Global CSS (consumers link `styles.css`):**
- `styles.css` — `@import` manifest only
- `tokens/colors.css` · `tokens/typography.css` · `tokens/spacing.css` · `tokens/effects.css` · `tokens/fonts.css`
- `base.css` — canvas, resets, helpers (`.container`, `.eyebrow`, `.text-gradient`, `.culltron-grid-bg`)

**Components** (`components/<group>/`) — React primitives, each with `.jsx` + `.d.ts` + `.prompt.md`, mounted from `window.CulltronDesignSystem_850f8b`:
- **core:** `Button`, `Badge`, `Chip`, `Card`, `Stat`
- **forms:** `Field`, `Input`, `Textarea`, `Select`
- **feedback:** `FAQ`
- **marketing:** `SectionHeading`, `ProductCard`, `ServiceCard`, `FeatureTile`, `CaseStudyCard`, `PricingCard`, `ProcessStep`, `CTABanner`, `WhatsAppFab`
- **navigation:** `Navbar`, `Footer`

**UI kit** (`ui_kits/website/`) — the full marketing site, all sharing the DS + `pagekit.jsx`:
- `index.html` — **showpiece animated homepage** (Tron hero, 11 sections)
- `products.html` · `services.html` · `solutions.html` (case studies) · `contact.html` · `product-detail.html` (reusable template) · `blog.html` (resources)
- supporting JSX: `GridFloor.jsx`, `Reveal.jsx`, `Hero.jsx`, `HomeSections.jsx`, `HomeSections2.jsx`, `pagekit.jsx`; CSS: `home.css`, `pages.css`

**Foundation cards** (`guidelines/*.card.html`) — colors, type, spacing/radii, brand/glyphs (render in the Design System tab).

**Assets** (`assets/`) — logo lockup, hexagon mark (incl. transparent), all product glyph PNGs.

---

## 7 · Developer handoff notes

- **One stylesheet to rule them all:** link `styles.css`. Everything is CSS custom properties — theme by overriding tokens, never hard-coded hex.
- **Tailwind mapping:** treat tokens as your theme. e.g. `bg-[--void]`, `text-[--ink]`, `border-[--line]`, `rounded-[--r-xl]`, `shadow-[--shadow-card]`, accent `text-[--accent]`. Display text → `font-[Space_Grotesk] tracking-[-0.04em]`; eyebrows → `font-mono uppercase tracking-[0.16em] text-[--accent]`.
- **Component naming** matches the exports above; compose pages from them (see `pagekit.jsx` for the Navbar/Footer/WhatsApp shell pattern and shared nav data).
- **Responsive:** every grid collapses 4→2→1; the navbar links hide < 900px (wire a mobile drawer at build); heroes restack with the visual on top; forms go single-column < 520px. Hit targets ≥ 44px.
- **Motion:** entrance animations gate on viewport (`Reveal`) and `prefers-reduced-motion`. The hero canvas caps DPR at 2 and pauses motion under reduced-motion. Safe for print/PDF.
- **Conversion:** persistent WhatsApp FAB on every page; three-tier CTA on every closing banner; demo/contact routes everywhere.
- **Out of scope (by request):** no payment processing, no CRM, no heavy backend — these are world-class UI/UX surfaces ready to wire to real services.

See `SKILL.md` to use this as a downloadable Claude/Agent skill.
