/* @ds-bundle: {"format":3,"namespace":"CulltronDesignSystem_850f8b","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"FAQ","sourcePath":"components/feedback/FAQ.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Field.jsx"},{"name":"Textarea","sourcePath":"components/forms/Field.jsx"},{"name":"Select","sourcePath":"components/forms/Field.jsx"},{"name":"CTABanner","sourcePath":"components/marketing/CTABanner.jsx"},{"name":"CaseStudyCard","sourcePath":"components/marketing/CaseStudyCard.jsx"},{"name":"FeatureTile","sourcePath":"components/marketing/FeatureTile.jsx"},{"name":"PricingCard","sourcePath":"components/marketing/PricingCard.jsx"},{"name":"ProcessStep","sourcePath":"components/marketing/ProcessStep.jsx"},{"name":"ProductCard","sourcePath":"components/marketing/ProductCard.jsx"},{"name":"SectionHeading","sourcePath":"components/marketing/SectionHeading.jsx"},{"name":"ServiceCard","sourcePath":"components/marketing/ServiceCard.jsx"},{"name":"WhatsAppFab","sourcePath":"components/marketing/WhatsAppFab.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Navbar","sourcePath":"components/navigation/Navbar.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"ba340206c1f5","components/core/Button.jsx":"0f188af8a93f","components/core/Card.jsx":"7ddcc53ac027","components/core/Chip.jsx":"e9e3ca2ef249","components/core/Stat.jsx":"0c59b26d901f","components/feedback/FAQ.jsx":"88ca20c19c5c","components/forms/Field.jsx":"f996dd1b3673","components/marketing/CTABanner.jsx":"2b94e4b3d482","components/marketing/CaseStudyCard.jsx":"c03f6d00b295","components/marketing/FeatureTile.jsx":"308deec68eef","components/marketing/PricingCard.jsx":"47a58c638a98","components/marketing/ProcessStep.jsx":"426d5c899f8e","components/marketing/ProductCard.jsx":"66872be23a1e","components/marketing/SectionHeading.jsx":"13fa9f99c1e7","components/marketing/ServiceCard.jsx":"7a8cc0f1eeb7","components/marketing/WhatsAppFab.jsx":"8b1e33f4e62e","components/navigation/Footer.jsx":"be2981e2b0b3","components/navigation/Navbar.jsx":"6a3d2a718b38","ui_kits/website/Cinematic.jsx":"3b1724e6d9b8","ui_kits/website/GridFloor.jsx":"5e32a97cd956","ui_kits/website/Hero.jsx":"48a2dedf2670","ui_kits/website/HomeSections.jsx":"da9de1e58bf4","ui_kits/website/HomeSections2.jsx":"b697e71c5044","ui_kits/website/Reveal.jsx":"3a63fe910450","ui_kits/website/pagekit.jsx":"418cd5c08137"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CulltronDesignSystem_850f8b = window.CulltronDesignSystem_850f8b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Culltron Badge — pill status indicator with tinted fill + matching border.
 */
function Badge({
  children,
  tone = 'cyan',
  dot = false,
  style = {},
  ...rest
}) {
  const tones = {
    cyan: {
      bg: 'rgba(0,212,255,.08)',
      color: '#aef0ff',
      border: 'rgba(0,212,255,.4)',
      dotc: 'var(--accent)'
    },
    blue: {
      bg: 'rgba(77,163,255,.12)',
      color: '#bcd8ff',
      border: 'rgba(77,163,255,.42)',
      dotc: 'var(--blue)'
    },
    violet: {
      bg: 'rgba(184,107,255,.12)',
      color: '#dcc4ff',
      border: 'rgba(184,107,255,.42)',
      dotc: 'var(--violet)'
    },
    green: {
      bg: 'rgba(61,220,151,.08)',
      color: '#9af0c8',
      border: 'rgba(61,220,151,.4)',
      dotc: 'var(--ok)'
    },
    amber: {
      bg: 'rgba(255,176,32,.08)',
      color: '#ffd98a',
      border: 'rgba(255,176,32,.4)',
      dotc: 'var(--warn)'
    },
    rose: {
      bg: 'rgba(255,90,90,.08)',
      color: '#ffb3b3',
      border: 'rgba(255,90,90,.4)',
      dotc: 'var(--danger)'
    },
    neutral: {
      bg: 'rgba(143,167,191,.1)',
      color: '#cdd9e6',
      border: 'rgba(143,167,191,.32)',
      dotc: 'var(--ink-faint)'
    }
  };
  const t = tones[tone] || tones.cyan;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.4rem',
      padding: '0.35rem 0.7rem',
      borderRadius: 'var(--r-pill)',
      background: t.bg,
      color: t.color,
      border: `1px solid ${t.border}`,
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.dotc,
      boxShadow: `0 0 8px ${t.dotc}`
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Culltron Button — pill, heavy weight, cyan-gradient primary.
 * Mirrors the in-product .btn system (CivicOps / Smart Port).
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '0.5rem 1rem',
      fontSize: '0.85rem'
    },
    md: {
      padding: '0.75rem 1.5rem',
      fontSize: '0.95rem'
    },
    lg: {
      padding: '0.95rem 2rem',
      fontSize: '1.05rem'
    }
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.55rem',
    fontFamily: 'var(--font-body)',
    fontWeight: 700,
    letterSpacing: '0.01em',
    borderRadius: 'var(--r-pill)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    width: fullWidth ? '100%' : 'auto',
    opacity: disabled ? 0.5 : 1,
    transition: 'transform var(--dur-fast) var(--ease-out), filter var(--dur-fast) var(--ease-out), background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)',
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: 'var(--grad-accent)',
      color: 'var(--ink-on-accent)',
      boxShadow: 'var(--glow-btn)',
      border: 'none'
    },
    secondary: {
      background: 'var(--fill-accent)',
      color: '#c9fbff',
      borderColor: 'var(--line-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-soft)',
      borderColor: 'var(--line-soft)'
    },
    light: {
      background: 'transparent',
      color: '#fff',
      borderColor: 'rgba(248,251,255,.45)'
    },
    whatsapp: {
      background: 'linear-gradient(135deg, #1faa55, #25d366)',
      color: '#04140a',
      border: 'none',
      boxShadow: '0 18px 45px rgba(37,211,102,.22)'
    }
  };
  const onEnter = e => {
    if (disabled) return;
    e.currentTarget.style.transform = 'translateY(-1px)';
    e.currentTarget.style.filter = 'brightness(1.06)';
    if (variant === 'secondary') e.currentTarget.style.background = 'var(--fill-accent-strong)';
    if (variant === 'ghost' || variant === 'light') e.currentTarget.style.background = 'rgba(0,212,255,.08)';
  };
  const onLeave = e => {
    if (disabled) return;
    e.currentTarget.style.transform = 'translateY(0)';
    e.currentTarget.style.filter = 'none';
    if (variant === 'secondary') e.currentTarget.style.background = 'var(--fill-accent)';
    if (variant === 'ghost' || variant === 'light') e.currentTarget.style.background = 'transparent';
  };
  const Tag = href ? 'a' : 'button';
  const props = href ? {
    href
  } : {
    disabled
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({}, props, {
    onMouseEnter: onEnter,
    onMouseLeave: onLeave,
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Culltron Card — the base glass-graphite surface. Gradient fill, cyan-tinted
 * hairline border, large radius, soft shadow + faint cyan glow. Optional hover lift.
 */
function Card({
  children,
  padding = 'lg',
  hover = false,
  glow = false,
  as = 'div',
  style = {},
  ...rest
}) {
  const pads = {
    none: 0,
    sm: '1rem',
    md: '1.35rem',
    lg: '1.75rem',
    xl: '2.25rem'
  };
  const Tag = as;
  const onEnter = e => {
    if (!hover) return;
    e.currentTarget.style.transform = 'translateY(-4px)';
    e.currentTarget.style.borderColor = 'var(--line-strong)';
  };
  const onLeave = e => {
    if (!hover) return;
    e.currentTarget.style.transform = 'translateY(0)';
    e.currentTarget.style.borderColor = 'var(--line)';
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    onMouseEnter: onEnter,
    onMouseLeave: onLeave,
    style: {
      position: 'relative',
      background: 'var(--grad-card)',
      border: '1px solid var(--line)',
      borderRadius: 'var(--r-xl)',
      padding: pads[padding],
      boxShadow: glow ? 'var(--shadow-card)' : 'var(--shadow-md)',
      color: 'var(--text)',
      transition: 'transform var(--dur-med) var(--ease-out), border-color var(--dur-med) var(--ease-out)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Culltron Chip — interactive pill (filter / tag / selectable).
 */
function Chip({
  children,
  active = false,
  icon,
  onClick,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.4rem',
      padding: '0.5rem 0.9rem',
      borderRadius: 'var(--r-pill)',
      background: active ? 'var(--fill-accent-strong)' : 'var(--surface-raised)',
      color: active ? '#eafdff' : 'var(--text-soft)',
      border: `1px solid ${active ? 'var(--line-strong)' : 'var(--line-soft)'}`,
      fontFamily: 'var(--font-body)',
      fontSize: '0.85rem',
      fontWeight: 600,
      cursor: 'pointer',
      transition: 'all var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, rest), icon, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
/**
 * Culltron Stat — big metric with label + optional delta. For impact / funder blocks.
 */
function Stat({
  value,
  label,
  sub,
  tone = 'cyan',
  align = 'left',
  style = {}
}) {
  const tones = {
    cyan: 'var(--accent)',
    blue: 'var(--blue)',
    green: 'var(--ok)',
    white: '#fff'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: align,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'clamp(2.4rem, 4vw, 3.6rem)',
      fontWeight: 700,
      lineHeight: 0.95,
      letterSpacing: 'var(--ls-tight)',
      color: tones[tone] || '#fff'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '0.55rem',
      color: 'var(--text)',
      fontWeight: 600,
      fontSize: '0.98rem'
    }
  }, label), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '0.25rem',
      color: 'var(--text-muted)',
      fontSize: '0.82rem'
    }
  }, sub));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/feedback/FAQ.jsx
try { (() => {
/**
 * Culltron FAQ accordion — single-open, animated chevron, cyan active line.
 * @param items [{ q, a }]
 */
function FAQ({
  items = [],
  defaultOpen = 0
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.75rem'
    }
  }, items.map((it, i) => {
    const isOpen = open === i;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        background: 'var(--grad-card)',
        border: `1px solid ${isOpen ? 'var(--line-strong)' : 'var(--line)'}`,
        borderRadius: 'var(--r-lg)',
        overflow: 'hidden',
        transition: 'border-color var(--dur-fast)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setOpen(isOpen ? -1 : i),
      style: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
        padding: '1.15rem 1.35rem',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        textAlign: 'left',
        color: 'var(--ink)',
        fontFamily: 'var(--font-display)',
        fontSize: '1.05rem',
        fontWeight: 600
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, it.q), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 'none',
        width: 26,
        height: 26,
        display: 'grid',
        placeItems: 'center',
        borderRadius: '50%',
        border: '1px solid var(--line)',
        color: 'var(--accent)',
        transform: isOpen ? 'rotate(45deg)' : 'none',
        transition: 'transform var(--dur-med) var(--ease-out)',
        fontSize: '1.1rem',
        lineHeight: 1
      }
    }, "+")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateRows: isOpen ? '1fr' : '0fr',
        transition: 'grid-template-rows var(--dur-med) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        padding: '0 1.35rem 1.3rem',
        color: 'var(--ink-dim)',
        fontSize: '0.95rem',
        lineHeight: 1.65,
        margin: 0
      }
    }, it.a))));
  }));
}
Object.assign(__ds_scope, { FAQ });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/FAQ.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Culltron Field — labelled input / textarea / select wrapper. Matches the
 * in-product .c-field + .c-input system (dark fill, cyan focus ring).
 */
function Field({
  label,
  hint,
  required = false,
  children
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '0.72rem',
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--ink-dim)',
      marginBottom: '0.45rem'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent)'
    }
  }, " *")), children, hint && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '0.72rem',
      color: 'var(--ink-faint)',
      marginTop: '0.4rem'
    }
  }, hint));
}
const baseControl = {
  width: '100%',
  padding: '0.7rem 0.85rem',
  borderRadius: 'var(--r-sm)',
  fontFamily: 'var(--font-body)',
  fontSize: '0.92rem',
  color: 'var(--ink)',
  background: 'rgba(4, 8, 16, 0.7)',
  border: '1px solid var(--line)',
  outline: 'none',
  transition: 'border-color var(--dur-fast), box-shadow var(--dur-fast)'
};
function focusOn(e) {
  e.currentTarget.style.borderColor = 'var(--accent)';
  e.currentTarget.style.boxShadow = 'var(--glow-focus)';
}
function focusOff(e) {
  e.currentTarget.style.borderColor = 'var(--line)';
  e.currentTarget.style.boxShadow = 'none';
}
function Input({
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("input", _extends({
    onFocus: focusOn,
    onBlur: focusOff,
    style: {
      ...baseControl,
      ...style
    }
  }, rest));
}
function Textarea({
  style = {},
  rows = 4,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    onFocus: focusOn,
    onBlur: focusOff,
    style: {
      ...baseControl,
      resize: 'vertical',
      minHeight: '6rem',
      ...style
    }
  }, rest));
}
function Select({
  children,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("select", _extends({
    onFocus: focusOn,
    onBlur: focusOff,
    style: {
      ...baseControl,
      appearance: 'none',
      paddingRight: '2.2rem',
      backgroundImage: 'linear-gradient(45deg, transparent 50%, var(--ink-dim) 50%), linear-gradient(135deg, var(--ink-dim) 50%, transparent 50%)',
      backgroundPosition: 'calc(100% - 18px) 55%, calc(100% - 13px) 55%',
      backgroundSize: '5px 5px',
      backgroundRepeat: 'no-repeat',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Field, Input, Textarea, Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/marketing/CTABanner.jsx
try { (() => {
/**
 * Culltron CTABanner — full-width conversion block. Glow panel with corner
 * brackets, headline, subline, and primary/secondary/WhatsApp actions.
 */
function CTABanner({
  eyebrow = 'Get started',
  title,
  subtitle,
  primary,
  secondary,
  whatsapp,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 'var(--r-2xl)',
      border: '1px solid var(--line-strong)',
      background: 'radial-gradient(900px 360px at 50% -40%, rgba(0,212,255,.18), transparent 70%), linear-gradient(180deg, var(--panel-3), var(--panel))',
      boxShadow: 'var(--shadow-lg)',
      padding: 'clamp(2.5rem, 5vw, 4.5rem)',
      textAlign: 'center',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'linear-gradient(rgba(0,212,255,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,.05) 1px, transparent 1px)',
      backgroundSize: '44px 44px',
      WebkitMaskImage: 'radial-gradient(70% 70% at 50% 30%, #000, transparent)',
      maskImage: 'radial-gradient(70% 70% at 50% 30%, #000, transparent)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--accent)',
      textTransform: 'uppercase',
      letterSpacing: '0.18em',
      fontSize: '0.72rem',
      fontWeight: 700,
      marginBottom: '1rem'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'clamp(1.9rem, 3.6vw, 3rem)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-tight)',
      lineHeight: 1.05,
      color: 'var(--ink)',
      margin: 0,
      maxWidth: 760,
      marginInline: 'auto'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: 'var(--fs-lead)',
      lineHeight: 1.6,
      margin: '1.1rem auto 0',
      maxWidth: 620
    }
  }, subtitle), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0.85rem',
      justifyContent: 'center',
      flexWrap: 'wrap',
      marginTop: '2rem'
    }
  }, primary && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "lg",
    href: primary.href
  }, primary.label), secondary && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary",
    size: "lg",
    href: secondary.href
  }, secondary.label), whatsapp && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "whatsapp",
    size: "lg",
    href: whatsapp.href
  }, whatsapp.label))));
}
Object.assign(__ds_scope, { CTABanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/CTABanner.jsx", error: String((e && e.message) || e) }); }

// components/marketing/CaseStudyCard.jsx
try { (() => {
/**
 * Culltron CaseStudyCard — Problem / Solution / Outcome structure with a CTA.
 * The flagship credibility block for the Solutions page.
 */
function CaseStudyCard({
  tag,
  title,
  summary,
  problem,
  solution,
  outcome,
  metrics = [],
  accent = 'var(--accent)',
  cta = 'Read the case study',
  href = '#',
  style = {}
}) {
  const Row = ({
    label,
    children
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '92px 1fr',
      gap: '0.85rem',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.66rem',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: accent,
      paddingTop: '0.15rem'
    }
  }, label), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.9rem',
      lineHeight: 1.6,
      margin: 0
    }
  }, children));
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    padding: "xl",
    glow: true,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1.25rem',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.75rem',
      flexWrap: 'wrap'
    }
  }, tag && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "cyan",
    dot: true
  }, tag)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h3)',
      fontWeight: 700,
      color: 'var(--ink)',
      margin: 0,
      lineHeight: 1.1
    }
  }, title), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '1rem',
      lineHeight: 1.6,
      marginTop: '0.6rem'
    }
  }, summary)), metrics.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '1.5rem',
      flexWrap: 'wrap',
      padding: '1rem 0',
      borderTop: '1px solid var(--line)',
      borderBottom: '1px solid var(--line)'
    }
  }, metrics.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.7rem',
      fontWeight: 700,
      color: accent,
      lineHeight: 1
    }
  }, m.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.78rem',
      color: 'var(--ink-faint)',
      marginTop: '0.3rem'
    }
  }, m.label)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.85rem'
    }
  }, problem && /*#__PURE__*/React.createElement(Row, {
    label: "Problem"
  }, problem), solution && /*#__PURE__*/React.createElement(Row, {
    label: "Solution"
  }, solution), outcome && /*#__PURE__*/React.createElement(Row, {
    label: "Outcome"
  }, outcome)), /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.5rem',
      color: accent,
      fontWeight: 600,
      fontSize: '0.9rem',
      marginTop: '0.25rem'
    }
  }, cta, " ", /*#__PURE__*/React.createElement("span", null, "\u2192")));
}
Object.assign(__ds_scope, { CaseStudyCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/CaseStudyCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/FeatureTile.jsx
try { (() => {
/**
 * Culltron FeatureTile — compact icon + title + line for feature grids.
 * Quieter than a Card; hairline separator style.
 */
function FeatureTile({
  icon,
  title,
  description,
  accent = 'var(--accent)',
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0.9rem',
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      flex: 'none',
      display: 'grid',
      placeItems: 'center',
      borderRadius: '10px',
      background: 'rgba(4,8,16,.5)',
      border: '1px solid var(--line)',
      color: accent
    }
  }, icon), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1rem',
      fontWeight: 600,
      color: 'var(--ink)',
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.85rem',
      lineHeight: 1.55,
      margin: '0.35rem 0 0'
    }
  }, description)));
}
Object.assign(__ds_scope, { FeatureTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/FeatureTile.jsx", error: String((e && e.message) || e) }); }

// components/marketing/PricingCard.jsx
try { (() => {
/**
 * Culltron PricingCard — plan/package card. Featured variant gets a cyan border,
 * glow and a "Most popular" ribbon. No payment flow — CTA only.
 */
function PricingCard({
  name,
  price,
  period = '/mo',
  blurb,
  features = [],
  cta = 'Get started',
  href = '#',
  featured = false,
  badge,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      gap: '1.2rem',
      background: featured ? 'linear-gradient(180deg, rgba(0,212,255,.10), var(--panel) 60%)' : 'var(--grad-card)',
      border: `1px solid ${featured ? 'var(--line-strong)' : 'var(--line)'}`,
      borderRadius: 'var(--r-xl)',
      padding: '2rem 1.75rem',
      boxShadow: featured ? 'var(--shadow-card)' : 'var(--shadow-md)',
      height: '100%',
      ...style
    }
  }, featured && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: -1,
      right: 24,
      transform: 'translateY(-50%)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "cyan",
    dot: true
  }, badge || 'Most popular')), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.1rem',
      fontWeight: 600,
      color: 'var(--ink)'
    }
  }, name), blurb && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.85rem',
      lineHeight: 1.5,
      marginTop: '0.4rem'
    }
  }, blurb)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '0.35rem'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '2.6rem',
      fontWeight: 700,
      color: 'var(--ink)',
      letterSpacing: '-0.03em',
      lineHeight: 1
    }
  }, price), period && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ink-faint)',
      fontSize: '0.9rem'
    }
  }, period)), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: featured ? 'primary' : 'secondary',
    href: href,
    fullWidth: true
  }, cta), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: '0.5rem 0 0',
      display: 'flex',
      flexDirection: 'column',
      gap: '0.7rem',
      borderTop: '1px solid var(--line)'
    }
  }, features.map((f, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      gap: '0.6rem',
      alignItems: 'flex-start',
      fontSize: '0.88rem',
      color: 'var(--ink-dim)',
      paddingTop: i === 0 ? '1rem' : 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent)',
      flex: 'none'
    }
  }, "\u2713"), f))));
}
Object.assign(__ds_scope, { PricingCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/PricingCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/ProcessStep.jsx
try { (() => {
/**
 * Culltron ProcessStep — one node in a numbered process / timeline. Use a row
 * of these for "how we work" or implementation timelines. Connector line built in.
 */
function ProcessStep({
  index,
  title,
  description,
  last = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '1.1rem',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 44,
      display: 'grid',
      placeItems: 'center',
      borderRadius: '50%',
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: '1.05rem',
      color: 'var(--accent)',
      background: 'rgba(4,8,16,.6)',
      border: '1px solid var(--line-strong)',
      boxShadow: 'var(--glow)'
    }
  }, String(index).padStart(2, '0')), !last && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      width: 1,
      marginTop: '0.5rem',
      background: 'linear-gradient(180deg, var(--line-strong), transparent)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: last ? 0 : '2rem'
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.1rem',
      fontWeight: 600,
      color: 'var(--ink)',
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.9rem',
      lineHeight: 1.6,
      margin: '0.4rem 0 0',
      maxWidth: 460
    }
  }, description)));
}
Object.assign(__ds_scope, { ProcessStep });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/ProcessStep.jsx", error: String((e && e.message) || e) }); }

// components/marketing/ProductCard.jsx
try { (() => {
/**
 * Culltron ProductCard — the suite tile. Brand glyph in an accent-tinted hex frame,
 * name, category, one-line summary, tier badge, hover lift + arrow.
 */
function ProductCard({
  icon,
  name,
  category,
  summary,
  tier,
  accent = 'var(--accent)',
  href = '#',
  style = {}
}) {
  const tierTone = tier === 'Free' ? 'green' : tier === 'Pro' ? 'cyan' : 'violet';
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    as: "a",
    href: href,
    hover: true,
    padding: "lg",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1rem',
      textDecoration: 'none',
      height: '100%',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: '0.75rem'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      flex: 'none',
      display: 'grid',
      placeItems: 'center',
      borderRadius: '14px',
      background: 'rgba(4,8,16,.6)',
      border: '1px solid var(--line)',
      boxShadow: `0 0 22px -6px ${accent}`
    }
  }, typeof icon === 'string' ? /*#__PURE__*/React.createElement("img", {
    src: icon,
    alt: "",
    style: {
      width: 38,
      height: 38
    }
  }) : icon), tier && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: tierTone
  }, tier)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.2rem',
      fontWeight: 700,
      color: 'var(--ink)',
      margin: 0
    }
  }, name), category && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.7rem',
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--ink-faint)',
      marginTop: '0.35rem'
    }
  }, category)), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.9rem',
      lineHeight: 1.6,
      margin: 0,
      flex: 1
    }
  }, summary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.5rem',
      color: accent,
      fontSize: '0.85rem',
      fontWeight: 600
    }
  }, "Explore", /*#__PURE__*/React.createElement("span", {
    style: {
      transition: 'transform var(--dur-fast)'
    }
  }, "\u2192")));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/SectionHeading.jsx
try { (() => {
/**
 * Culltron SectionHeading — eyebrow (mono cyan) + display title + lead.
 */
function SectionHeading({
  eyebrow,
  title,
  lead,
  align = 'left',
  maxWidth = 640,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: align,
      maxWidth: align === 'center' ? maxWidth : 'none',
      marginInline: align === 'center' ? 'auto' : 0,
      ...style
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--accent)',
      textTransform: 'uppercase',
      letterSpacing: '0.18em',
      fontSize: '0.72rem',
      fontWeight: 700,
      marginBottom: '0.9rem',
      display: 'flex',
      alignItems: 'center',
      gap: '0.6rem',
      justifyContent: align === 'center' ? 'center' : 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 1,
      background: 'var(--accent)',
      boxShadow: 'var(--glow)'
    }
  }), eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h2)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-tight)',
      lineHeight: 1.05,
      color: 'var(--ink)',
      margin: 0
    }
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: '1rem',
      color: 'var(--ink-dim)',
      fontSize: 'var(--fs-lead)',
      lineHeight: 1.6,
      maxWidth: maxWidth,
      marginInline: align === 'center' ? 'auto' : 0
    }
  }, lead));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/marketing/ServiceCard.jsx
try { (() => {
/**
 * Culltron ServiceCard — icon, title, description, optional bullet list.
 * Used on the Services page and "What Culltron Builds" grid.
 */
function ServiceCard({
  icon,
  title,
  description,
  points = [],
  accent = 'var(--accent)',
  style = {}
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    hover: true,
    padding: "lg",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.9rem',
      height: '100%',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 46,
      height: 46,
      display: 'grid',
      placeItems: 'center',
      borderRadius: '12px',
      background: 'var(--fill-accent)',
      border: '1px solid var(--line)',
      color: accent
    }
  }, icon), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '1.15rem',
      fontWeight: 700,
      color: 'var(--ink)',
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.9rem',
      lineHeight: 1.6,
      margin: 0
    }
  }, description), points.length > 0 && /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: '0.2rem 0 0',
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem'
    }
  }, points.map((p, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      gap: '0.6rem',
      alignItems: 'flex-start',
      fontSize: '0.85rem',
      color: 'var(--ink-dim)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent,
      flex: 'none',
      marginTop: '0.05rem'
    }
  }, "\u25B8"), p))));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/marketing/WhatsAppFab.jsx
try { (() => {
/**
 * Culltron WhatsAppFab — floating WhatsApp CTA, fixed bottom-right.
 * Brand green, pulse ring, expands to a label on hover.
 */
function WhatsAppFab({
  phone = '',
  label = 'Talk on WhatsApp',
  message = '',
  style = {}
}) {
  const href = phone ? `https://wa.me/${phone.replace(/[^0-9]/g, '')}${message ? '?text=' + encodeURIComponent(message) : ''}` : '#';
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    target: "_blank",
    rel: "noopener",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'fixed',
      right: '1.5rem',
      bottom: '1.5rem',
      zIndex: 90,
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.6rem',
      padding: hover ? '0.85rem 1.25rem 0.85rem 0.9rem' : '0.85rem',
      borderRadius: 'var(--r-pill)',
      textDecoration: 'none',
      background: 'linear-gradient(135deg, #1faa55, #25d366)',
      color: '#04140a',
      fontWeight: 700,
      fontSize: '0.92rem',
      boxShadow: '0 12px 36px rgba(37,211,102,.4)',
      transition: 'padding var(--dur-med) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: 26,
      height: 26,
      flex: 'none',
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21 5.46 0 9.91-4.45 9.91-9.91S17.5 2 12.04 2zm0 18.15c-1.53 0-3.03-.41-4.34-1.19l-.31-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.36c0-4.54 3.7-8.23 8.24-8.23 4.54 0 8.23 3.69 8.23 8.23s-3.69 8.23-8.23 8.23zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.16.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.25 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.22-.16-.47-.28z"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: -4,
      borderRadius: '50%',
      border: '2px solid rgba(37,211,102,.5)',
      animation: 'cull-pulse 2.2s var(--ease-out) infinite'
    }
  })), hover && /*#__PURE__*/React.createElement("span", {
    style: {
      whiteSpace: 'nowrap'
    }
  }, label), /*#__PURE__*/React.createElement("style", null, `@keyframes cull-pulse{0%{transform:scale(.9);opacity:.7}70%{transform:scale(1.35);opacity:0}100%{opacity:0}}`));
}
Object.assign(__ds_scope, { WhatsAppFab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/WhatsAppFab.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
/**
 * Culltron Footer — product / service / company columns, brand lockup, legal row.
 */
function Footer({
  logo,
  columns = [],
  tagline,
  legal = '© Culltron. All rights reserved.',
  socials = [],
  style = {}
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      position: 'relative',
      borderTop: '1px solid var(--line)',
      background: 'linear-gradient(180deg, transparent, rgba(4,8,16,.6))',
      paddingTop: 'var(--space-9)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-wide)',
      margin: '0 auto',
      padding: '0 var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(220px, 1.4fr) repeat(auto-fit, minmax(140px, 1fr))',
      gap: '2.5rem',
      paddingBottom: 'var(--space-8)'
    },
    className: "cull-footer-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.6rem',
      textDecoration: 'none'
    }
  }, logo && /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "Culltron",
    style: {
      width: 34,
      height: 34,
      filter: 'drop-shadow(0 0 8px rgba(0,212,255,.5))'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: '1.2rem',
      color: 'var(--ink)'
    }
  }, "Cull", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent)'
    }
  }, "tron"))), tagline && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.9rem',
      lineHeight: 1.6,
      marginTop: '1rem',
      maxWidth: 300
    }
  }, tagline), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0.6rem',
      marginTop: '1.25rem'
    }
  }, socials.map((s, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: s.href,
    "aria-label": s.label,
    style: {
      width: 38,
      height: 38,
      display: 'grid',
      placeItems: 'center',
      borderRadius: '10px',
      border: '1px solid var(--line)',
      color: 'var(--ink-dim)',
      background: 'rgba(4,8,16,.4)'
    }
  }, s.icon)))), columns.map((col, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.68rem',
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--ink-faint)',
      marginBottom: '1rem'
    }
  }, col.title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '0.7rem'
    }
  }, col.links.map((l, j) => /*#__PURE__*/React.createElement("li", {
    key: j
  }, /*#__PURE__*/React.createElement("a", {
    href: l.href,
    style: {
      color: 'var(--ink-dim)',
      fontSize: '0.9rem',
      textDecoration: 'none'
    },
    onMouseEnter: e => e.currentTarget.style.color = 'var(--ink)',
    onMouseLeave: e => e.currentTarget.style.color = 'var(--ink-dim)'
  }, l.label))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '1rem',
      flexWrap: 'wrap',
      padding: '1.5rem 0',
      borderTop: '1px solid var(--line)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ink-faint)',
      fontSize: '0.82rem'
    }
  }, legal), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--ink-faint)',
      fontSize: '0.74rem',
      letterSpacing: '0.1em'
    }
  }, "BUILT IN SOUTH AFRICA \xB7 culltron.tech"))), /*#__PURE__*/React.createElement("style", null, `@media (max-width:720px){.cull-footer-grid{grid-template-columns:1fr 1fr!important}}`));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Navbar.jsx
try { (() => {
/**
 * Culltron Navbar — sticky glass chrome. Brand lockup, primary links,
 * primary + ghost actions. Shrinks / gains a stronger backdrop on scroll.
 * @param logo  path to the brand mark png
 */
function Navbar({
  logo,
  links = [],
  cta = {
    label: 'Request a Demo',
    href: '#'
  },
  secondary = {
    label: 'Sign in',
    href: '#'
  },
  active = '',
  style = {}
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 80,
      background: scrolled ? 'rgba(6,10,18,.82)' : 'rgba(6,10,18,.35)',
      backdropFilter: 'var(--blur-glass)',
      WebkitBackdropFilter: 'var(--blur-glass)',
      borderBottom: `1px solid ${scrolled ? 'var(--line)' : 'transparent'}`,
      transition: 'background var(--dur-med), border-color var(--dur-med)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-wide)',
      margin: '0 auto',
      padding: '0 var(--gutter)',
      height: scrolled ? 64 : 74,
      display: 'flex',
      alignItems: 'center',
      gap: '2rem',
      transition: 'height var(--dur-med)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.65rem',
      textDecoration: 'none',
      flex: 'none'
    }
  }, logo && /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "Culltron",
    style: {
      width: 32,
      height: 32,
      filter: 'drop-shadow(0 0 8px rgba(0,212,255,.5))'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: '1.15rem',
      letterSpacing: '0.02em',
      color: 'var(--ink)'
    }
  }, "Cull", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent)',
      textShadow: 'var(--glow-text)'
    }
  }, "tron"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.35rem',
      marginLeft: '0.5rem'
    },
    className: "cull-nav-links"
  }, links.map((l, i) => {
    const isActive = active && l.label === active;
    return /*#__PURE__*/React.createElement("a", {
      key: i,
      href: l.href,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.35rem',
        padding: '0.5rem 0.85rem',
        borderRadius: 'var(--r-sm)',
        fontSize: '0.9rem',
        fontWeight: 500,
        color: isActive ? 'var(--ink)' : 'var(--ink-dim)',
        background: isActive ? 'var(--fill-accent)' : 'transparent',
        textDecoration: 'none',
        transition: 'color var(--dur-fast), background var(--dur-fast)'
      },
      onMouseEnter: e => {
        e.currentTarget.style.color = 'var(--ink)';
      },
      onMouseLeave: e => {
        if (!isActive) e.currentTarget.style.color = 'var(--ink-dim)';
      }
    }, l.label, l.caret && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '0.6rem',
        opacity: 0.6
      }
    }, "\u25BE"));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: '0.7rem'
    }
  }, secondary && /*#__PURE__*/React.createElement("a", {
    href: secondary.href,
    style: {
      fontSize: '0.9rem',
      fontWeight: 600,
      color: 'var(--ink-dim)'
    },
    className: "cull-nav-secondary"
  }, secondary.label), cta && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    href: cta.href
  }, cta.label))), /*#__PURE__*/React.createElement("style", null, `@media (max-width:900px){.cull-nav-links{display:none!important}.cull-nav-secondary{display:none!important}}`));
}
Object.assign(__ds_scope, { Navbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Navbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Cinematic.jsx
try { (() => {
/* Cinematic.jsx — scroll-driven "warp through the Culltron world" intro.
   A pinned 3D stage. Scroll progress (0→1) is the camera:
     scene 1 (0–.30)  deep space, the Culltron core emerges and rushes past
     scene 2 (.10–.80) WARP — product glyphs + sparks streak past the camera
     scene 3 (.55–1)  ARRIVAL — constellation + Hero-B headline + CTAs settle
   Respects reduced-motion / touch → falls back to the static <Hero variant="B">. */
function CinematicHero() {
  const wrapRef = React.useRef(null);
  const gridRef = React.useRef(null);
  const coreRef = React.useRef(null);
  const eyebrowRef = React.useRef(null);
  const introRef = React.useRef(null);
  const warpRef = React.useRef(null);
  const finaleRef = React.useRef(null);
  const cueRef = React.useRef(null);
  const flyRefs = React.useRef([]);

  // build the flyby field once
  const FIELD = React.useMemo(() => {
    const glyphs = ['app-office-max', 'app-aria', 'app-pdf-max', 'app-video-max', 'app-data-max', 'app-studio-max', 'app-diagram-max', 'app-sentinel', 'app-forge-max', 'app-bridge', 'app-asset-store', 'app-app-hub'];
    const acc = {
      'app-office-max': '#00d4ff',
      'app-aria': '#b86bff',
      'app-pdf-max': '#ff5a5a',
      'app-video-max': '#ff7a45',
      'app-data-max': '#4da3ff',
      'app-studio-max': '#41e08d',
      'app-diagram-max': '#ffc24d',
      'app-sentinel': '#00d4ff',
      'app-forge-max': '#ff7a45',
      'app-bridge': '#4da3ff',
      'app-asset-store': '#00d4ff',
      'app-app-hub': '#41e08d'
    };
    const items = [];
    // product glyphs
    glyphs.forEach((g, i) => {
      const ang = i / glyphs.length * Math.PI * 2 + (i % 2 ? 0.4 : 0);
      items.push({
        type: 'glyph',
        g,
        a: acc[g],
        ang,
        rad: 0.16 + i % 3 * 0.12,
        phase: i / glyphs.length,
        cycles: 1,
        size: 46 + i % 3 * 14
      });
    });
    // warp sparks
    for (let i = 0; i < 46; i++) {
      const ang = Math.random() * Math.PI * 2;
      items.push({
        type: 'spark',
        ang,
        rad: 0.05 + Math.random() * 0.5,
        phase: Math.random(),
        cycles: 2 + Math.floor(Math.random() * 2),
        size: 2 + Math.random() * 3,
        a: Math.random() > 0.7 ? '#6be4ff' : '#00d4ff'
      });
    }
    return items;
  }, []);
  const reduced = React.useMemo(() => {
    if (typeof window === 'undefined') return false;
    const rm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const small = window.matchMedia('(max-width: 700px)').matches;
    return rm || small;
  }, []);
  React.useEffect(() => {
    if (reduced) return;
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const lerp = (a, b, t) => a + (b - a) * t;
    const ease = t => t * t * (3 - 2 * t);
    let raf;
    const frame = () => {
      const wrap = wrapRef.current;
      if (!wrap) {
        raf = requestAnimationFrame(frame);
        return;
      }
      const rect = wrap.getBoundingClientRect();
      const total = wrap.offsetHeight - window.innerHeight;
      const p = clamp(-rect.top / total, 0, 1);
      const vw = window.innerWidth,
        vh = window.innerHeight;
      const cx = vw / 2,
        cy = vh / 2;

      // ---- GRID FLOOR forward travel ----
      if (gridRef.current) {
        const speed = lerp(600, 2600, p);
        gridRef.current.style.backgroundPositionY = `${p * speed % 1000}px`;
        gridRef.current.style.opacity = `${clamp(0.85 - Math.abs(p - 0.45) * 1.1, 0.05, 0.85)}`;
      }

      // ---- SCENE 1: core emerges & rushes past (0 → .6) ----
      if (coreRef.current) {
        const cp = clamp(p / 0.55, 0, 1);
        const scale = lerp(0.42, 2.6, ease(cp));
        const z = lerp(-700, 380, ease(cp));
        const op = p > 0.5 ? clamp(1 - (p - 0.5) / 0.12, 0, 1) : clamp(0.6 + p * 2.2, 0, 1);
        coreRef.current.style.transform = `translate(-50%, -50%) translateZ(${z}px) scale(${scale})`;
        coreRef.current.style.opacity = `${op}`;
      }
      if (eyebrowRef.current) {
        const op = p > 0.16 ? clamp(1 - (p - 0.16) / 0.08, 0, 1) : 1;
        eyebrowRef.current.style.opacity = `${op}`;
        eyebrowRef.current.style.transform = `translate(-50%, -50%) translateY(${lerp(-92, -150, p)}px)`;
      }

      // ---- SCENE 2: WARP field (.08 → .82) ----
      const w0 = 0.08,
        w1 = 0.82;
      const wp = clamp((p - w0) / (w1 - w0), 0, 1);
      const warpVisible = p > 0.02 && p < 0.86;
      if (warpRef.current) warpRef.current.style.opacity = warpVisible ? `${clamp(Math.min((p - 0.02) / 0.06, (0.86 - p) / 0.06), 0, 1)}` : '0';
      FIELD.forEach((it, i) => {
        const el = flyRefs.current[i];
        if (!el) return;
        // each item cycles through the camera repeatedly during warp
        const t = ((wp * it.cycles + it.phase) % 1 + 1) % 1;
        const et = t * t; // accelerate toward camera
        const dist = Math.pow(t, 2.7) * Math.max(vw, vh) * 0.95 * it.rad / 0.3;
        const x = Math.cos(it.ang) * dist;
        const y = Math.sin(it.ang) * dist * 0.78;
        const scale = lerp(0.12, it.type === 'glyph' ? 2.9 : 2.2, et);
        const op = t < 0.12 ? t / 0.12 : t > 0.74 ? clamp((1 - t) / 0.26, 0, 1) : 1;
        el.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
        el.style.opacity = warpVisible ? `${op}` : '0';
      });

      // ---- SCENE 3: ARRIVAL (.55 → 1) ----
      if (finaleRef.current) {
        const fp = clamp((p - 0.56) / 0.24, 0, 1);
        finaleRef.current.style.opacity = `${ease(fp)}`;
        finaleRef.current.style.transform = `translate(-50%, -50%) translateZ(${lerp(-260, 0, ease(fp))}px) scale(${lerp(0.92, 1, ease(fp))})`;
        finaleRef.current.style.pointerEvents = fp > 0.6 ? 'auto' : 'none';
      }

      // scroll cue fades almost immediately
      if (cueRef.current) cueRef.current.style.opacity = `${clamp(1 - p / 0.06, 0, 1)}`;
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [reduced, FIELD]);
  const {
    Button,
    Badge
  } = window.CulltronDesignSystem_850f8b;
  if (reduced) {
    // clean static fallback — the polished Hero B
    return /*#__PURE__*/React.createElement(window.Hero, {
      variant: "B"
    });
  }
  return /*#__PURE__*/React.createElement("section", {
    className: "cine",
    ref: wrapRef,
    "data-screen-label": "Cinematic hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cine-stage"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cine-bg"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cine-grid",
    ref: gridRef
  }), /*#__PURE__*/React.createElement("div", {
    className: "cine-eyebrow",
    ref: eyebrowRef,
    style: {
      transform: 'translate(-50%,-50%) translateY(-92px)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "cine-eyebrow-mono"
  }, "SOFTWARE \xB7 INTELLIGENCE \xB7 INFRASTRUCTURE")), /*#__PURE__*/React.createElement("div", {
    className: "cine-core",
    ref: coreRef,
    style: {
      opacity: 0.6,
      transform: 'translate(-50%,-50%) scale(0.42)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cine-core-ring"
  }), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/culltron-mark-512.png",
    alt: "Culltron"
  })), /*#__PURE__*/React.createElement("div", {
    className: "cine-warp",
    ref: warpRef,
    style: {
      opacity: 0
    }
  }, FIELD.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "cine-fly",
    ref: el => flyRefs.current[i] = el
  }, it.type === 'glyph' ? /*#__PURE__*/React.createElement("div", {
    className: "cine-glyph",
    style: {
      width: it.size,
      height: it.size,
      borderColor: it.a + '88',
      boxShadow: `0 0 24px -4px ${it.a}`
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `../../assets/icons/${it.g}.png`,
    alt: ""
  })) : /*#__PURE__*/React.createElement("span", {
    className: "cine-spark",
    style: {
      width: it.size,
      height: it.size,
      background: it.a,
      boxShadow: `0 0 10px ${it.a}`
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "cine-finale",
    ref: finaleRef,
    style: {
      opacity: 0,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cine-finale-viz"
  }, /*#__PURE__*/React.createElement(window.HeroConstellation, null)), /*#__PURE__*/React.createElement("div", {
    className: "cine-finale-copy"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: '1.3rem'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "cyan",
    dot: true
  }, "Built for the next economy")), /*#__PURE__*/React.createElement("h1", {
    className: "cine-title"
  }, "Build smarter. Operate faster.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    className: "text-gradient"
  }, "Launch with Culltron.")), /*#__PURE__*/React.createElement("p", {
    className: "cine-sub"
  }, "From business websites and automation to municipal intelligence platforms and productivity software, Culltron turns complex operations into clean digital systems."), /*#__PURE__*/React.createElement("div", {
    className: "cine-cta"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => document.getElementById('ecosystem').scrollIntoView({
      behavior: 'smooth'
    })
  }, "Explore Culltron"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    href: "contact.html"
  }, "Request a Demo"), /*#__PURE__*/React.createElement(Button, {
    variant: "whatsapp",
    size: "lg"
  }, "Talk on WhatsApp")))), /*#__PURE__*/React.createElement("div", {
    className: "cine-cue",
    ref: cueRef
  }, /*#__PURE__*/React.createElement("span", {
    className: "cine-cue-word"
  }, "SCROLL TO ENTER"), /*#__PURE__*/React.createElement("span", {
    className: "cine-cue-track"
  }, /*#__PURE__*/React.createElement("i", null))), /*#__PURE__*/React.createElement("div", {
    className: "cine-vignette"
  })));
}
window.CinematicHero = CinematicHero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Cinematic.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/GridFloor.jsx
try { (() => {
/* GridFloor — animated Tron perspective grid + drifting light particles + cursor glow.
   Pure canvas, capped DPR, respects reduced-motion. Mount once behind the hero. */
function GridFloor({
  height = '100%',
  density = 1,
  showParticles = true
}) {
  const ref = React.useRef(null);
  const mouse = React.useRef({
    x: 0.5,
    y: 0.4,
    active: false
  });
  React.useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let w = 0,
      h = 0,
      dpr = Math.min(window.devicePixelRatio || 1, 2);
    let raf,
      t = 0;
    const particles = [];
    const PN = showParticles ? Math.round(46 * density) : 0;
    for (let i = 0; i < PN; i++) {
      particles.push({
        x: Math.random(),
        y: Math.random(),
        z: Math.random(),
        s: 0.4 + Math.random() * 1.4,
        sp: 0.02 + Math.random() * 0.08
      });
    }
    function resize() {
      const r = canvas.getBoundingClientRect();
      w = r.width;
      h = r.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener('resize', resize);
    function draw() {
      t += reduce ? 0 : 1;
      ctx.clearRect(0, 0, w, h);

      // ---- perspective grid floor (lower 55%) ----
      const horizon = h * 0.46;
      const vpx = w * (0.5 + (mouse.current.x - 0.5) * 0.12);
      const rows = 26;
      const speed = reduce ? 0 : t * 0.0016;
      ctx.lineWidth = 1;
      // vertical converging lines
      const cols = Math.round(24 * density);
      for (let i = -cols; i <= cols; i++) {
        const fx = i / cols;
        const bx = vpx + fx * w * 1.7;
        ctx.beginPath();
        ctx.moveTo(vpx, horizon);
        ctx.lineTo(bx, h);
        const a = 0.16 * (1 - Math.abs(fx) * 0.7);
        ctx.strokeStyle = `rgba(0,212,255,${Math.max(0, a)})`;
        ctx.stroke();
      }
      // horizontal scrolling lines (perspective spaced)
      for (let r = 0; r < rows; r++) {
        let p = (r / rows + speed) % 1;
        const yy = horizon + Math.pow(p, 2.4) * (h - horizon);
        const a = 0.5 * (1 - p) * p * 4;
        ctx.beginPath();
        ctx.moveTo(0, yy);
        ctx.lineTo(w, yy);
        ctx.strokeStyle = `rgba(0,212,255,${Math.max(0, Math.min(0.22, a * 0.22))})`;
        ctx.stroke();
      }

      // glow band on the horizon
      const g = ctx.createLinearGradient(0, horizon - 60, 0, horizon + 30);
      g.addColorStop(0, 'rgba(0,212,255,0)');
      g.addColorStop(1, 'rgba(0,212,255,0.10)');
      ctx.fillStyle = g;
      ctx.fillRect(0, horizon - 60, w, 90);

      // ---- floating particles (upper area) ----
      for (const pt of particles) {
        if (!reduce) {
          pt.y -= pt.sp * 0.004;
          if (pt.y < 0) {
            pt.y = 1;
            pt.x = Math.random();
          }
        }
        const px = pt.x * w,
          py = pt.y * horizon;
        const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 0.02 + pt.z * 9));
        ctx.beginPath();
        ctx.arc(px, py, pt.s, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${pt.z > 0.7 ? '120,228,255' : '0,212,255'},${0.5 * tw})`;
        ctx.shadowColor = 'rgba(0,212,255,0.8)';
        ctx.shadowBlur = 6;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // ---- cursor glow ----
      if (mouse.current.active) {
        const mg = ctx.createRadialGradient(mouse.current.x * w, mouse.current.y * h, 0, mouse.current.x * w, mouse.current.y * h, 220);
        mg.addColorStop(0, 'rgba(0,212,255,0.10)');
        mg.addColorStop(1, 'rgba(0,212,255,0)');
        ctx.fillStyle = mg;
        ctx.fillRect(0, 0, w, h);
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    const onMove = e => {
      const r = canvas.getBoundingClientRect();
      mouse.current = {
        x: (e.clientX - r.left) / r.width,
        y: (e.clientY - r.top) / r.height,
        active: true
      };
    };
    const onLeave = () => {
      mouse.current.active = false;
    };
    const parent = canvas.parentElement;
    parent.addEventListener('mousemove', onMove);
    parent.addEventListener('mouseleave', onLeave);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      parent.removeEventListener('mousemove', onMove);
      parent.removeEventListener('mouseleave', onLeave);
    };
  }, [density, showParticles]);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height,
      display: 'block',
      pointerEvents: 'none'
    }
  });
}
window.GridFloor = GridFloor;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/GridFloor.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
/* Hero — Culltron showpiece hero. Kinetic headline over the GridFloor with a
   rotating holographic product constellation (real app glyphs orbiting a core). */
function HeroConstellation() {
  // orbiting real product glyphs around the Culltron core
  const apps = [{
    ico: 'app-office-max',
    a: '#00d4ff'
  }, {
    ico: 'app-aria',
    a: '#b86bff'
  }, {
    ico: 'app-pdf-max',
    a: '#ff5a5a'
  }, {
    ico: 'app-video-max',
    a: '#ff7a45'
  }, {
    ico: 'app-data-max',
    a: '#4da3ff'
  }, {
    ico: 'app-studio-max',
    a: '#41e08d'
  }, {
    ico: 'app-diagram-max',
    a: '#ffc24d'
  }, {
    ico: 'app-sentinel',
    a: '#00d4ff'
  }];
  const ring1 = apps.slice(0, 4),
    ring2 = apps.slice(4);
  return /*#__PURE__*/React.createElement("div", {
    className: "hero-constellation",
    style: {
      position: 'relative',
      width: 'min(440px, 84vw)',
      aspectRatio: '1',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "orbit orbit-1"
  }), /*#__PURE__*/React.createElement("div", {
    className: "orbit orbit-2"
  }), /*#__PURE__*/React.createElement("div", {
    className: "orbit orbit-3"
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-core"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/culltron-mark-512.png",
    alt: "Culltron",
    style: {
      width: '46%',
      height: '46%',
      filter: 'drop-shadow(0 0 26px rgba(0,212,255,.85))'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "ring-spin ring-spin-a"
  }, ring1.map((app, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "ring-node",
    style: {
      transform: `rotate(${i * 90}deg) translateX(calc(min(440px,84vw) * 0.5)) rotate(-${i * 90}deg)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "node-counter"
  }, /*#__PURE__*/React.createElement("div", {
    className: "glyph-tile",
    style: {
      boxShadow: `0 0 20px -4px ${app.a}`,
      borderColor: app.a + '66'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `../../assets/icons/${app.ico}.png`,
    alt: "",
    style: {
      width: 30,
      height: 30
    }
  })))))), /*#__PURE__*/React.createElement("div", {
    className: "ring-spin ring-spin-b"
  }, ring2.map((app, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "ring-node",
    style: {
      transform: `rotate(${i * 90 + 45}deg) translateX(calc(min(440px,84vw) * 0.34)) rotate(-${i * 90 + 45}deg)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "node-counter-b"
  }, /*#__PURE__*/React.createElement("div", {
    className: "glyph-tile sm",
    style: {
      boxShadow: `0 0 16px -4px ${app.a}`,
      borderColor: app.a + '66'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: `../../assets/icons/${app.ico}.png`,
    alt: "",
    style: {
      width: 22,
      height: 22
    }
  })))))), /*#__PURE__*/React.createElement("div", {
    className: "hero-scan"
  }));
}
function Hero({
  variant = 'A',
  onCta
}) {
  const heads = {
    A: ['Intelligent software systems', 'for the next economy.'],
    B: ['Build smarter. Operate faster.', 'Launch with Culltron.'],
    C: ['Software, AI, and infrastructure', '— built as one ecosystem.']
  };
  const subs = {
    A: 'Culltron builds AI-powered platforms, desktop software, automation tools, and digital infrastructure for businesses, municipalities, and modern teams.',
    B: 'From business websites and automation to municipal intelligence platforms and productivity software, Culltron turns complex operations into clean digital systems.',
    C: 'Culltron brings together custom software, intelligent workflows, product platforms, and client-ready digital systems under one technology brand.'
  };
  const {
    Button,
    Badge
  } = window.CulltronDesignSystem_850f8b;
  const [l1, l2] = heads[variant] || heads.A;
  return /*#__PURE__*/React.createElement("section", {
    className: "hero",
    "data-screen-label": "Hero"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(GridFloor, {
    height: "100%",
    density: 1
  })), /*#__PURE__*/React.createElement("div", {
    className: "hero-vignette"
  }), /*#__PURE__*/React.createElement("div", {
    className: "container hero-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-copy"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-eyebrow reveal-up",
    style: {
      animationDelay: '.05s'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "cyan",
    dot: true
  }, "Software \xB7 Intelligence \xB7 Infrastructure")), /*#__PURE__*/React.createElement("h1", {
    className: "hero-title"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hero-line"
  }, /*#__PURE__*/React.createElement("span", {
    className: "reveal-mask",
    style: {
      animationDelay: '.12s'
    }
  }, l1)), /*#__PURE__*/React.createElement("span", {
    className: "hero-line"
  }, /*#__PURE__*/React.createElement("span", {
    className: "reveal-mask text-gradient",
    style: {
      animationDelay: '.26s'
    }
  }, l2))), /*#__PURE__*/React.createElement("p", {
    className: "hero-sub reveal-up",
    style: {
      animationDelay: '.5s'
    }
  }, subs[variant] || subs.A), /*#__PURE__*/React.createElement("div", {
    className: "hero-cta reveal-up",
    style: {
      animationDelay: '.62s'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: onCta
  }, "Explore Culltron"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg"
  }, "Request a Demo"), /*#__PURE__*/React.createElement(Button, {
    variant: "whatsapp",
    size: "lg"
  }, "Talk on WhatsApp")), /*#__PURE__*/React.createElement("div", {
    className: "hero-trust reveal-up",
    style: {
      animationDelay: '.74s'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Trusted across"), /*#__PURE__*/React.createElement("strong", null, "Business"), /*#__PURE__*/React.createElement("i", null, "\xB7"), /*#__PURE__*/React.createElement("strong", null, "Municipal"), /*#__PURE__*/React.createElement("i", null, "\xB7"), /*#__PURE__*/React.createElement("strong", null, "Logistics"), /*#__PURE__*/React.createElement("i", null, "\xB7"), /*#__PURE__*/React.createElement("strong", null, "Public sector"))), /*#__PURE__*/React.createElement("div", {
    className: "hero-visual reveal-up",
    style: {
      animationDelay: '.4s'
    }
  }, /*#__PURE__*/React.createElement(HeroConstellation, null))), /*#__PURE__*/React.createElement("div", {
    className: "hero-scrollcue"
  }, /*#__PURE__*/React.createElement("span", null)));
}
window.Hero = Hero;
window.HeroConstellation = HeroConstellation;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeSections.jsx
try { (() => {
/* HomeSections — the Culltron homepage body. Composes DS components + Reveal. */
const DS = () => window.CulltronDesignSystem_850f8b;
const ICO = n => `../../assets/icons/${n}.png`;

/* ---- thin inline line-icons (stroke matches Lucide weight) ---- */
function LineIcon({
  d,
  size = 22
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, d);
}
const I = {
  cpu: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
      x: "4",
      y: "4",
      width: "16",
      height: "16",
      rx: "2"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "9",
      y: "9",
      width: "6",
      height: "6"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"
    }))
  }),
  bolt: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "M13 2 3 14h9l-1 8 10-12h-9z"
    })
  }),
  layers: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "m12 2 9 5-9 5-9-5 9-5Z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m3 12 9 5 9-5"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m3 17 9 5 9-5"
    }))
  }),
  globe: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "9"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"
    }))
  }),
  shield: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "M12 2 4 6v6c0 5 3.5 8 8 10 4.5-2 8-5 8-10V6l-8-4Z"
    })
  }),
  building: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
      x: "4",
      y: "3",
      width: "16",
      height: "18",
      rx: "1"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M9 8h.01M15 8h.01M9 12h.01M15 12h.01M9 16h6"
    }))
  }),
  monitor: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "4",
      width: "18",
      height: "12",
      rx: "2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M8 20h8M12 16v4"
    }))
  }),
  code: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "m8 6-6 6 6 6M16 6l6 6-6 6"
    })
  }),
  users: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "9",
      cy: "8",
      r: "3"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M21 20a6 6 0 0 0-3-5"
    }))
  }),
  workflow: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "3",
      width: "7",
      height: "7",
      rx: "1"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "14",
      y: "14",
      width: "7",
      height: "7",
      rx: "1"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 6.5h4a3 3 0 0 1 3 3V14"
    }))
  }),
  spark: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3"
    })
  }),
  chart: /*#__PURE__*/React.createElement(LineIcon, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M3 3v18h18"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m7 14 3-4 3 3 4-6"
    }))
  })
};

/* ====== TRUST MARQUEE ====== */
function TrustMarquee() {
  const items = ['BUSINESS OPERATIONS', 'MUNICIPAL SYSTEMS', 'PORT & LOGISTICS', 'AI WORKFLOWS', 'DESKTOP SOFTWARE', 'DIGITAL INFRASTRUCTURE', 'PUBLIC SECTOR', 'AUTOMATION'];
  const row = [...items, ...items];
  return /*#__PURE__*/React.createElement("div", {
    className: "marquee"
  }, /*#__PURE__*/React.createElement("div", {
    className: "marquee-track"
  }, row.map((t, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: "marquee-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marquee-dot"
  }), t))));
}

/* ====== WHAT CULLTRON BUILDS ====== */
function EcosystemSection() {
  const {
    SectionHeading
  } = DS();
  const pillars = [{
    icon: I.layers,
    t: 'Product platforms',
    d: 'A unified suite of desktop and intelligence products built on one shared runtime.',
    a: '#00d4ff'
  }, {
    icon: I.cpu,
    t: 'AI & automation',
    d: 'Agentic workflows, document intelligence, and user-controlled AI across every surface.',
    a: '#b86bff'
  }, {
    icon: I.building,
    t: 'Operational systems',
    d: 'Municipal, logistics and public-sector platforms that turn live data into decisions.',
    a: '#4da3ff'
  }, {
    icon: I.globe,
    t: 'Digital infrastructure',
    d: 'Custom software, client portals, and websites engineered for the next economy.',
    a: '#41e08d'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    "data-screen-label": "What Culltron Builds"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    maxWidth: 680,
    eyebrow: "What Culltron builds",
    title: "One technology brand. A full ecosystem of intelligent systems.",
    lead: "Culltron designs, builds and ships software across four connected layers \u2014 so businesses, municipalities and teams get a coherent system, not scattered tools."
  })), /*#__PURE__*/React.createElement("div", {
    className: "grid-4",
    style: {
      marginTop: '3.5rem'
    }
  }, pillars.map((p, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: i,
    delay: i * 90
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pillar-icon",
    style: {
      color: p.a,
      boxShadow: `inset 0 0 0 1px ${p.a}33, 0 0 26px -10px ${p.a}`
    }
  }, p.icon), /*#__PURE__*/React.createElement("h3", {
    className: "pillar-title"
  }, p.t), /*#__PURE__*/React.createElement("p", {
    className: "pillar-desc"
  }, p.d), /*#__PURE__*/React.createElement("div", {
    className: "pillar-line",
    style: {
      background: `linear-gradient(90deg, ${p.a}, transparent)`
    }
  })))))));
}

/* ====== FEATURED PRODUCTS ====== */
function ProductsSection() {
  const {
    SectionHeading,
    ProductCard,
    Button
  } = DS();
  const products = [{
    ico: 'app-office-max',
    name: 'Culltron Office Max',
    cat: 'Productivity',
    tier: 'Pro',
    a: '#00d4ff',
    s: 'Documents, spreadsheets with a real formula engine, and decks — fully offline.'
  }, {
    ico: 'app-aria',
    name: 'Aria',
    cat: 'AI workspace',
    tier: 'Free',
    a: '#b86bff',
    s: 'User-controlled AI: offline rules, local model or your own API. Never auto-runs.'
  }, {
    ico: 'app-data-max',
    name: 'Culltron Data Max',
    cat: 'Analytics',
    tier: 'Pro',
    a: '#4da3ff',
    s: 'Connect, model and visualise operational data with live dashboards.'
  }, {
    ico: 'app-video-max',
    name: 'Culltron Video Max',
    cat: 'Creative',
    tier: 'Pro',
    a: '#ff7a45',
    s: 'Timeline editing, captions and export — a full studio on the desktop.'
  }, {
    ico: 'app-pdf-max',
    name: 'Culltron PDF Max',
    cat: 'Documents',
    tier: 'Pro',
    a: '#ff5a5a',
    s: 'Merge, split, sign, compress and batch-process PDFs entirely offline.'
  }, {
    ico: 'app-sentinel',
    name: 'Sentinel',
    cat: 'Security',
    tier: 'Business',
    a: '#00d4ff',
    s: 'Runtime hardening, sandboxing and signed offline licensing for the suite.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section section-alt",
    "data-screen-label": "Featured products"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "section-head-row"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Product ecosystem",
    title: "A serious software suite \u2014 not a list of apps.",
    lead: "Every Culltron product runs on one shared runtime, with a common design language and offline-first foundations."
  })), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "View all products \u2192"))), /*#__PURE__*/React.createElement("div", {
    className: "grid-3",
    style: {
      marginTop: '3rem'
    }
  }, products.map((p, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: i,
    delay: i % 3 * 90
  }, /*#__PURE__*/React.createElement(ProductCard, {
    icon: ICO(p.ico),
    name: p.name,
    category: p.cat,
    tier: p.tier,
    accent: p.a,
    summary: p.s
  }))))));
}

/* ====== AI & AUTOMATION CAPABILITY (split + holо panel) ====== */
function AISection() {
  const {
    SectionHeading,
    FeatureTile,
    Badge
  } = DS();
  const feats = [{
    icon: I.spark,
    t: 'Agentic workflows',
    d: 'Compose multi-step automations that read, decide and act across your systems.'
  }, {
    icon: I.workflow,
    t: 'Document intelligence',
    d: 'Extract, classify and route documents with explainable, auditable results.'
  }, {
    icon: I.shield,
    t: 'User-controlled AI',
    d: 'Offline rules, local models or your own API keys. Nothing runs without consent.'
  }, {
    icon: I.code,
    t: 'Developer tools',
    d: 'APIs, SDKs and an automation suite to wire Culltron into anything you run.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    "data-screen-label": "AI and automation"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container ai-split"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "AI & automation",
    title: "AI-powered workflows you actually control.",
    lead: "Culltron's intelligence layer is transparent by design \u2014 metered, model-aware, and built so a human always stays in command."
  })), /*#__PURE__*/React.createElement("div", {
    className: "ai-feats"
  }, feats.map((f, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: i,
    delay: i * 80
  }, /*#__PURE__*/React.createElement(FeatureTile, {
    icon: f.icon,
    title: f.t,
    description: f.d
  }))))), /*#__PURE__*/React.createElement(Reveal, {
    delay: 140
  }, /*#__PURE__*/React.createElement("div", {
    className: "ai-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ai-panel-head"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: ICO('app-aria'),
    alt: "",
    style: {
      width: 26,
      height: 26
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "ai-panel-title"
  }, "Aria \xB7 Workflow run")), /*#__PURE__*/React.createElement(Badge, {
    tone: "green",
    dot: true
  }, "Live")), /*#__PURE__*/React.createElement("div", {
    className: "ai-log"
  }, [{
    k: 'INPUT',
    t: '142 supplier invoices ingested',
    a: '#4da3ff'
  }, {
    k: 'CLASSIFY',
    t: 'Matched to 3 cost centres · 98.4% conf.',
    a: '#00d4ff'
  }, {
    k: 'EXTRACT',
    t: 'Totals, VAT, due dates structured',
    a: '#b86bff'
  }, {
    k: 'REVIEW',
    t: '4 flagged for human approval',
    a: '#ffc24d'
  }, {
    k: 'ACTION',
    t: 'Posted to ledger · audit trail saved',
    a: '#41e08d'
  }].map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "ai-log-row",
    style: {
      animationDelay: `${i * 0.12}s`
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ai-log-k",
    style: {
      color: r.a,
      borderColor: r.a + '55'
    }
  }, r.k), /*#__PURE__*/React.createElement("span", {
    className: "ai-log-t"
  }, r.t), /*#__PURE__*/React.createElement("span", {
    className: "ai-log-tick",
    style: {
      color: r.a
    }
  }, "\u2713")))), /*#__PURE__*/React.createElement("div", {
    className: "ai-panel-foot"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ai-meter"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ai-meter-fill"
  })), /*#__PURE__*/React.createElement("span", {
    className: "ai-meter-label"
  }, "Est. 142 credits \xB7 model-transparent"))))));
}
window.DS = DS;
window.ICO = ICO;
window.HomeIcons = I;
window.TrustMarquee = TrustMarquee;
window.EcosystemSection = EcosystemSection;
window.ProductsSection = ProductsSection;
window.AISection = AISection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeSections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeSections2.jsx
try { (() => {
/* HomeSections2 — municipal intelligence, proof, audiences, mission, CTA. */

/* ====== MUNICIPAL / OPERATIONS INTELLIGENCE (dashboard mock) ====== */
function MunicipalSection() {
  const {
    SectionHeading,
    Badge
  } = DS();
  const I = window.HomeIcons;
  return /*#__PURE__*/React.createElement("section", {
    className: "section section-alt",
    "data-screen-label": "Operations intelligence"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    maxWidth: 700,
    eyebrow: "Operations intelligence",
    title: "Live operating pictures for municipalities and infrastructure.",
    lead: "AfriGrid Nexus and CivicOps turn fragmented public-sector data into one real-time console \u2014 resilience, service delivery and response, unified."
  })), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-chrome"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-dots"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)), /*#__PURE__*/React.createElement("div", {
    className: "dash-tabs"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dash-tab active"
  }, "AfriGrid Nexus"), /*#__PURE__*/React.createElement("span", {
    className: "dash-tab"
  }, "CivicOps"), /*#__PURE__*/React.createElement("span", {
    className: "dash-tab"
  }, "Smart Port Flow")), /*#__PURE__*/React.createElement(Badge, {
    tone: "green",
    dot: true
  }, "All systems nominal")), /*#__PURE__*/React.createElement("div", {
    className: "dash-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-side"
  }, [['◉', 'Resilience'], ['▤', 'Water grid'], ['⚡', 'Power'], ['◷', 'Incidents'], ['◍', 'Service intake'], ['❖', 'Reports']].map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: 'dash-nav' + (i === 0 ? ' active' : '')
  }, /*#__PURE__*/React.createElement("span", {
    className: "dash-nav-ico"
  }, r[0]), r[1]))), /*#__PURE__*/React.createElement("div", {
    className: "dash-main"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-stats"
  }, [{
    l: 'Grid resilience',
    v: '94.2%',
    d: '+2.1',
    a: '#41e08d'
  }, {
    l: 'Active incidents',
    v: '7',
    d: '-3',
    a: '#00d4ff'
  }, {
    l: 'Avg. response',
    v: '18m',
    d: '-22%',
    a: '#b86bff'
  }, {
    l: 'Service requests',
    v: '1,284',
    d: '+12%',
    a: '#4da3ff'
  }].map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "dash-stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-stat-l"
  }, s.l), /*#__PURE__*/React.createElement("div", {
    className: "dash-stat-v"
  }, s.v), /*#__PURE__*/React.createElement("div", {
    className: "dash-stat-d",
    style: {
      color: s.a
    }
  }, s.d)))), /*#__PURE__*/React.createElement("div", {
    className: "dash-row"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-chart"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-chart-head"
  }, /*#__PURE__*/React.createElement("span", null, "Network load \xB7 24h"), /*#__PURE__*/React.createElement("span", {
    className: "dash-chart-tag"
  }, "Real-time")), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 320 110",
    preserveAspectRatio: "none",
    className: "dash-spark"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "cg",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "rgba(0,212,255,.35)"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "rgba(0,212,255,0)"
  }))), /*#__PURE__*/React.createElement("path", {
    d: "M0,80 C30,60 50,84 80,64 C110,46 130,70 160,52 C190,36 210,58 240,40 C270,26 290,46 320,30 L320,110 L0,110 Z",
    fill: "url(#cg)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M0,80 C30,60 50,84 80,64 C110,46 130,70 160,52 C190,36 210,58 240,40 C270,26 290,46 320,30",
    fill: "none",
    stroke: "#00d4ff",
    strokeWidth: "1.8",
    className: "dash-spark-line"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dash-feed"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dash-feed-head"
  }, "Incident feed"), [{
    t: 'Pump station 4 · pressure restored',
    a: '#41e08d'
  }, {
    t: 'Ward 12 · outage report logged',
    a: '#ffc24d'
  }, {
    t: 'Reservoir B · level normal',
    a: '#00d4ff'
  }, {
    t: 'Crew dispatched · ETA 12m',
    a: '#b86bff'
  }].map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "dash-feed-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dash-feed-dot",
    style: {
      background: f.a,
      boxShadow: `0 0 8px ${f.a}`
    }
  }), f.t))))))))));
}

/* ====== PROOF / IMPACT (funder block) ====== */
function ProofSection() {
  const stats = [{
    to: 14,
    suf: '',
    l: 'Products in the suite',
    s: 'Desktop, AI & platform'
  }, {
    to: 39,
    suf: '+',
    l: 'Free tools shipped',
    s: 'On the shared runtime'
  }, {
    to: 100,
    suf: '%',
    l: 'Offline-capable core',
    s: 'No cloud lock-in'
  }, {
    to: 4,
    suf: '',
    l: 'Operational sectors',
    s: 'Biz · Gov · Logistics · Creative'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    "data-screen-label": "Proof and impact"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("div", {
    className: "proof"
  }, /*#__PURE__*/React.createElement("div", {
    className: "proof-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: '.8rem'
    }
  }, "Built for scale"), /*#__PURE__*/React.createElement("h2", {
    className: "proof-title"
  }, "Funder-ready foundations, ", /*#__PURE__*/React.createElement("span", {
    className: "text-gradient"
  }, "commercial from day one."))), /*#__PURE__*/React.createElement("div", {
    className: "proof-grid"
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "proof-stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "proof-num"
  }, /*#__PURE__*/React.createElement(CountUp, {
    to: s.to,
    suffix: s.suf
  })), /*#__PURE__*/React.createElement("div", {
    className: "proof-l"
  }, s.l), /*#__PURE__*/React.createElement("div", {
    className: "proof-s"
  }, s.s))))))));
}

/* ====== USE CASES BY AUDIENCE ====== */
function AudienceSection() {
  const {
    SectionHeading
  } = DS();
  const I = window.HomeIcons;
  const auds = [{
    icon: I.building,
    t: 'Businesses & SMEs',
    d: 'Websites, automation, dashboards and internal tools that cut manual work.',
    a: '#00d4ff'
  }, {
    icon: I.globe,
    t: 'Municipalities',
    d: 'Resilience, service intake and operations platforms for the public sector.',
    a: '#4da3ff'
  }, {
    icon: I.chart,
    t: 'Funders & incubators',
    d: 'A credible, investable technology brand with a shipping product ecosystem.',
    a: '#41e08d'
  }, {
    icon: I.users,
    t: 'Creators & teams',
    d: 'Productivity and creative software that runs fast, offline, on any desktop.',
    a: '#b86bff'
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "section section-alt",
    "data-screen-label": "Use cases by audience"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Built for",
    title: "One platform, many operators."
  })), /*#__PURE__*/React.createElement("div", {
    className: "grid-4",
    style: {
      marginTop: '2.5rem'
    }
  }, auds.map((a, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: i,
    delay: i * 80
  }, /*#__PURE__*/React.createElement("div", {
    className: "aud"
  }, /*#__PURE__*/React.createElement("div", {
    className: "aud-icon",
    style: {
      color: a.a
    }
  }, a.icon), /*#__PURE__*/React.createElement("h3", {
    className: "aud-t"
  }, a.t), /*#__PURE__*/React.createElement("p", {
    className: "aud-d"
  }, a.d), /*#__PURE__*/React.createElement("a", {
    className: "aud-link",
    style: {
      color: a.a
    },
    href: "#"
  }, "See use cases \u2192")))))));
}

/* ====== FOUNDER / MISSION ====== */
function MissionSection() {
  return /*#__PURE__*/React.createElement("section", {
    className: "section",
    "data-screen-label": "Mission"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("div", {
    className: "mission"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mission-mark"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/culltron-mark-512.png",
    alt: "Culltron"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: '1rem'
    }
  }, "Our mission"), /*#__PURE__*/React.createElement("blockquote", {
    className: "mission-quote"
  }, "\"We build the intelligent software layer for the next economy \u2014 engineered in South Africa, designed to operate anywhere. Serious systems for the people who run businesses, cities and infrastructure.\""), /*#__PURE__*/React.createElement("div", {
    className: "mission-by"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mission-name"
  }, "Culltron"), /*#__PURE__*/React.createElement("span", {
    className: "mission-role"
  }, "Software \xB7 Intelligence \xB7 Infrastructure")))))));
}
window.MunicipalSection = MunicipalSection;
window.ProofSection = ProofSection;
window.AudienceSection = AudienceSection;
window.MissionSection = MissionSection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeSections2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Reveal.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Reveal — fade+rise on scroll into view. <Reveal delay={120}><div/></Reveal> */
function Reveal({
  children,
  delay = 0,
  y = 24,
  as = 'div',
  style = {},
  ...rest
}) {
  const ref = React.useRef(null);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      setShown(true);
      return;
    }
    const el = ref.current;
    const io = new IntersectionObserver(es => {
      es.forEach(e => {
        if (e.isIntersecting) {
          setShown(true);
          io.unobserve(e.target);
        }
      });
    }, {
      threshold: 0.14,
      rootMargin: '0px 0px -8% 0px'
    });
    if (el) io.observe(el);
    return () => io.disconnect();
  }, []);
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    ref: ref,
    style: {
      opacity: shown ? 1 : 0,
      transform: shown ? 'translateY(0)' : `translateY(${y}px)`,
      transition: `opacity .7s cubic-bezier(.22,1,.36,1) ${delay}ms, transform .7s cubic-bezier(.22,1,.36,1) ${delay}ms`,
      ...style
    }
  }, rest), children);
}

/* CountUp — animates an integer when scrolled into view */
function CountUp({
  to,
  suffix = '',
  prefix = '',
  dur = 1400,
  style = {}
}) {
  const ref = React.useRef(null);
  const [val, setVal] = React.useState(0);
  React.useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      setVal(to);
      return;
    }
    const el = ref.current;
    let raf;
    const io = new IntersectionObserver(es => {
      if (es[0].isIntersecting) {
        const start = performance.now();
        const tick = now => {
          const p = Math.min(1, (now - start) / dur);
          const e = 1 - Math.pow(1 - p, 3);
          setVal(Math.round(to * e));
          if (p < 1) raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
        io.unobserve(el);
      }
    }, {
      threshold: 0.5
    });
    if (el) io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [to, dur]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: style
  }, prefix, val.toLocaleString(), suffix);
}
window.Reveal = Reveal;
window.CountUp = CountUp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Reveal.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/pagekit.jsx
try { (() => {
/* pagekit — shared chrome (Navbar + Footer + WhatsApp) and nav data for all
   Culltron marketing pages. Exposes window.PageShell + window.SectionTitle. */
const CDS = () => window.CulltronDesignSystem_850f8b;
const NAV = [{
  label: 'Products',
  href: 'products.html',
  caret: true
}, {
  label: 'Services',
  href: 'services.html',
  caret: true
}, {
  label: 'Solutions',
  href: 'solutions.html'
}, {
  label: 'Pricing',
  href: 'product-detail.html'
}, {
  label: 'Resources',
  href: 'blog.html'
}];
const FCOLS = [{
  title: 'Products',
  links: [{
    label: 'Office Max',
    href: 'product-detail.html'
  }, {
    label: 'Aria AI'
  }, {
    label: 'AfriGrid Nexus'
  }, {
    label: 'CivicOps'
  }, {
    label: 'Smart Port Flow'
  }]
}, {
  title: 'Services',
  links: [{
    label: 'Custom websites',
    href: 'services.html'
  }, {
    label: 'Automation'
  }, {
    label: 'AI integration'
  }, {
    label: 'Client portals'
  }]
}, {
  title: 'Company',
  links: [{
    label: 'About'
  }, {
    label: 'Solutions',
    href: 'solutions.html'
  }, {
    label: 'Resources',
    href: 'blog.html'
  }, {
    label: 'Contact',
    href: 'contact.html'
  }]
}, {
  title: 'Connect',
  links: [{
    label: 'Request a demo',
    href: 'contact.html'
  }, {
    label: 'WhatsApp'
  }, {
    label: 'Email us'
  }, {
    label: 'Careers'
  }]
}];
const SOCIAL = d => React.createElement('svg', {
  width: 17,
  height: 17,
  viewBox: '0 0 24 24',
  fill: 'currentColor'
}, d);
const SOCIALS = [{
  label: 'X',
  icon: SOCIAL(/*#__PURE__*/React.createElement("path", {
    d: "M18 2h3l-7 8 8 12h-6l-5-7-6 7H2l8-9L2 2h6l4 6 6-6Z"
  }))
}, {
  label: 'LinkedIn',
  icon: SOCIAL(/*#__PURE__*/React.createElement("path", {
    d: "M4 4a2 2 0 1 1 0 4 2 2 0 0 1 0-4ZM3 9h2v11H3V9Zm5 0h2v2a3 3 0 0 1 3-2c2 0 3 1.5 3 4v7h-2v-6c0-1.5-.5-2.5-2-2.5S11 13 11 15v5H8V9Z"
  }))
}, {
  label: 'GitHub',
  icon: SOCIAL(/*#__PURE__*/React.createElement("path", {
    d: "M12 2a10 10 0 0 0-3 19.5c.5 0 .7-.2.7-.5v-2c-2.8.6-3.4-1.2-3.4-1.2-.5-1.1-1.1-1.4-1.1-1.4-.9-.6 0-.6 0-.6 1 0 1.5 1 1.5 1 .9 1.5 2.3 1 2.9.8 0-.6.3-1 .6-1.3-2.2-.2-4.5-1.1-4.5-5 0-1 .4-1.9 1-2.5 0-.3-.4-1.3.1-2.6 0 0 .8-.3 2.7 1a9.3 9.3 0 0 1 5 0c1.9-1.3 2.7-1 2.7-1 .5 1.3.2 2.3.1 2.6.6.6 1 1.5 1 2.5 0 3.9-2.3 4.8-4.5 5 .3.3.6.9.6 1.8v2.6c0 .3.2.6.7.5A10 10 0 0 0 12 2Z"
  }))
}];
function PageShell({
  active,
  children
}) {
  const {
    Navbar,
    Footer,
    WhatsAppFab
  } = CDS();
  const mark = '../../assets/icons/culltron-mark-256.png';
  return /*#__PURE__*/React.createElement("div", {
    className: "culltron-grid-bg"
  }, /*#__PURE__*/React.createElement(Navbar, {
    logo: mark,
    active: active,
    links: NAV,
    cta: {
      label: 'Request a Demo',
      href: 'contact.html'
    },
    secondary: {
      label: 'Sign in'
    }
  }), children, /*#__PURE__*/React.createElement(Footer, {
    logo: mark,
    tagline: "Software. Intelligence. Infrastructure. Built for the next economy \u2014 engineered in South Africa.",
    columns: FCOLS,
    socials: SOCIALS
  }), /*#__PURE__*/React.createElement(WhatsAppFab, {
    phone: "27 82 000 0000",
    message: "Hi Culltron \u2014 I'd like to talk about a project."
  }));
}

/* Page hero band (compact, for inner pages) */
function PageHero({
  eyebrow,
  title,
  lead,
  children
}) {
  const {
    Badge
  } = CDS();
  return /*#__PURE__*/React.createElement("section", {
    className: "page-hero",
    "data-screen-label": "Page hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page-hero-grid"
  }), /*#__PURE__*/React.createElement("div", {
    className: "container page-hero-inner"
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: '1.2rem'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "cyan",
    dot: true
  }, eyebrow)), /*#__PURE__*/React.createElement("h1", {
    className: "page-hero-title"
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    className: "page-hero-lead"
  }, lead), children && /*#__PURE__*/React.createElement("div", {
    className: "page-hero-actions"
  }, children)));
}
function bootWhenReady(render, extra = []) {
  const need = ['PageShell', 'PageHero', 'Reveal', ...extra];
  (function poll() {
    const ok = need.every(k => typeof window[k] !== 'undefined') && window.CulltronDesignSystem_850f8b && window.CulltronDesignSystem_850f8b.Navbar;
    if (!ok) {
      requestAnimationFrame(poll);
      return;
    }
    render();
  })();
}
window.PageShell = PageShell;
window.PageHero = PageHero;
window.bootWhenReady = bootWhenReady;
window.PK = {
  NAV,
  FCOLS,
  SOCIALS
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/pagekit.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.FAQ = __ds_scope.FAQ;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.CTABanner = __ds_scope.CTABanner;

__ds_ns.CaseStudyCard = __ds_scope.CaseStudyCard;

__ds_ns.FeatureTile = __ds_scope.FeatureTile;

__ds_ns.PricingCard = __ds_scope.PricingCard;

__ds_ns.ProcessStep = __ds_scope.ProcessStep;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.WhatsAppFab = __ds_scope.WhatsAppFab;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Navbar = __ds_scope.Navbar;

})();
